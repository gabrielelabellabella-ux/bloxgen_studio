import React, { useState, useMemo, useEffect, useRef } from "react";
import { Header } from "./components/Header";
import { ExplorerSidebar } from "./components/ExplorerSidebar";
import { LuaEditor } from "./components/LuaEditor";
import { AiPromptBar } from "./components/AiPromptBar";
import { RealtimeDebugger } from "./components/RealtimeDebugger";
import { ScreenshotUiConverter } from "./components/ScreenshotUiConverter";
import { AssetManager } from "./components/AssetManager";
import { LightingFxStudio } from "./components/LightingFxStudio";
import { PerformanceOptimizer } from "./components/PerformanceOptimizer";
import { RobloxStudioBridge } from "./components/RobloxStudioBridge";
import { PluginInstallTutorialModal } from "./components/PluginInstallTutorialModal";
import { ProjectFile, ScriptType, GraphicAsset } from "./types";
import { INITIAL_PROJECT_FILES } from "./utils/defaultProject";
import { analyzeLuauSyntax } from "./utils/luauParser";
import { sfx } from "./utils/soundEffects";

export default function App() {
  const [files, setFiles] = useState<ProjectFile[]>(INITIAL_PROJECT_FILES);
  const [activeFileId, setActiveFileId] = useState<string>(INITIAL_PROJECT_FILES[0].id);
  const [activeTab, setActiveTab] = useState<
    "editor" | "ui-converter" | "assets" | "lighting-fx" | "profiler" | "studio-bridge"
  >("editor");

  // Prompt Generator State
  const [selectedScriptType, setSelectedScriptType] = useState<ScriptType>("Server");
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [isFixing, setIsFixing] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isGlobalTutorialOpen, setIsGlobalTutorialOpen] = useState<boolean>(false);

  // Roblox Studio Live Connection State
  const [isStudioConnected, setIsStudioConnected] = useState<boolean>(false);
  const [studioPlaceName, setStudioPlaceName] = useState<string>("");
  const [autoSyncEnabled, setAutoSyncEnabled] = useState<boolean>(true);
  const autoSyncDebounceRef = useRef<NodeJS.Timeout | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Poll connection state to Roblox Studio
  useEffect(() => {
    let mounted = true;
    const pollSyncStatus = async () => {
      try {
        const res = await fetch("/api/sync/status");
        if (res.ok) {
          const data = await res.json();
          if (mounted && data.success) {
            setIsStudioConnected(Boolean(data.connected));
            if (data.session?.placeName) {
              setStudioPlaceName(data.session.placeName);
            }
            if (typeof data.session?.autoSync === "boolean") {
              setAutoSyncEnabled(data.session.autoSync);
            }
          }
        }
      } catch (err) {
        // Silently retry
      }
    };

    pollSyncStatus();
    const interval = setInterval(pollSyncStatus, 2000);
    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, []);

  // Automatic push helper to Roblox Studio
  const pushFileToStudio = async (file: ProjectFile, silent: boolean = false) => {
    try {
      const res = await fetch("/api/sync/push", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          file: {
            id: file.id,
            name: file.name,
            type: file.type,
            parentPath: file.parentPath,
            content: file.content,
          },
        }),
      });
      const data = await res.json();
      if (data.success && !silent && isStudioConnected) {
        showToast(`⚡ '${file.name}' sincronizzato in Roblox Studio!`);
      }
    } catch (e) {
      console.error("Errore push Studio:", e);
    }
  };

  // Find active file
  const activeFile = useMemo(() => {
    return files.find((f) => f.id === activeFileId) || files[0];
  }, [files, activeFileId]);

  // Real-time syntax check on the active file
  const syntaxIssues = useMemo(() => {
    if (!activeFile || !activeFile.content) return [];
    return analyzeLuauSyntax(activeFile.content);
  }, [activeFile?.content]);

  // Update code in active file (debounced auto-sync to Studio)
  const handleUpdateCode = (newCode: string) => {
    setFiles((prev) =>
      prev.map((f) =>
        f.id === activeFile.id ? { ...f, content: newCode, modifiedAt: Date.now() } : f
      )
    );

    // If autoSync is enabled, push to Studio after brief debounce
    if (autoSyncEnabled) {
      if (autoSyncDebounceRef.current) clearTimeout(autoSyncDebounceRef.current);
      autoSyncDebounceRef.current = setTimeout(() => {
        pushFileToStudio({ ...activeFile, content: newCode }, true);
      }, 800);
    }
  };

  // Create new script in explorer
  const handleCreateScript = (parentPath: string, type: ScriptType, name: string) => {
    const newFile: ProjectFile = {
      id: `script-${Date.now()}`,
      name,
      type,
      parentPath,
      modifiedAt: Date.now(),
      content: `--!strict\n-- ${parentPath}.${name}\n\nlocal Players = game:GetService("Players")\n\nprint("[${name}] Inizializzato.")\n`,
    };
    setFiles((prev) => [...prev, newFile]);
    setActiveFileId(newFile.id);
    setActiveTab("editor");
    showToast(`Script '${name}' creato in ${parentPath}`);

    if (autoSyncEnabled) {
      pushFileToStudio(newFile);
    }
  };

  // Delete script
  const handleDeleteFile = (id: string) => {
    if (files.length <= 1) {
      showToast("Impossibile eliminare l'unico script rimasto nel progetto.");
      return;
    }
    sfx.playWarn();
    const remaining = files.filter((f) => f.id !== id);
    setFiles(remaining);
    if (activeFileId === id) {
      setActiveFileId(remaining[0].id);
    }
    showToast("Script eliminato.");
  };

  // AI Generation from prompt
  const handleGenerateLua = async (
    promptText: string,
    scriptType: ScriptType,
    assetImages: { data: string; mimeType: string }[]
  ) => {
    setIsGenerating(true);
    sfx.playLaser();
    try {
      const res = await fetch("/api/gemini/generate-lua", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: promptText,
          scriptType,
          existingCode: activeFile.content,
          projectStructure: files.map((f) => ({ name: f.name, path: f.parentPath, type: f.type })),
          assetImages,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || "Errore nella generazione con Gemini 3.8");
      }

      sfx.playSuccess();

      // Check if user requested updating the existing active file or creating a new one
      const isTargetingCurrent =
        promptText.toLowerCase().includes("modifica") ||
        promptText.toLowerCase().includes("aggiorna") ||
        promptText.toLowerCase().includes("estendi");

      if (isTargetingCurrent && activeFile) {
        handleUpdateCode(data.code);
        showToast(`Script '${activeFile.name}' aggiornato da Gemini 3.8!`);
        if (autoSyncEnabled) {
          pushFileToStudio({ ...activeFile, content: data.code });
        }
      } else {
        const generatedFile: ProjectFile = {
          id: `gen-${Date.now()}`,
          name: (data.title || "NuovoScript").replace(/[^a-zA-Z0-9_]/g, ""),
          type: (data.scriptType as ScriptType) || scriptType,
          parentPath: data.location || (scriptType === "Server" ? "ServerScriptService" : "StarterPlayer"),
          description: data.summary,
          content: data.code,
          modifiedAt: Date.now(),
        };
        setFiles((prev) => [generatedFile, ...prev]);
        setActiveFileId(generatedFile.id);
        showToast(`Nuovo script '${generatedFile.name}' generato con successo!`);
        if (autoSyncEnabled) {
          pushFileToStudio(generatedFile);
        }
      }

      setActiveTab("editor");
    } catch (err: any) {
      sfx.playWarn();
      console.error(err);
      showToast(`Errore: ${err.message || "Errore di connessione a Gemini 3.8"}`);
    } finally {
      setIsGenerating(false);
    }
  };

  // Instant AI Auto-Fix
  const handleTriggerAiFix = async () => {
    setIsFixing(true);
    try {
      const res = await fetch("/api/gemini/debug-lua", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code: activeFile.content,
          detectedErrors: syntaxIssues,
          context: `${activeFile.type} in ${activeFile.parentPath}`,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || "Errore durante il debug");
      }

      if (data.fixedCode) {
        handleUpdateCode(data.fixedCode);
        showToast("Errori di sintassi risolti istantaneamente da Gemini 3.8!");
        if (autoSyncEnabled) {
          pushFileToStudio({ ...activeFile, content: data.fixedCode });
        }
      }
    } catch (err: any) {
      showToast(`Errore debug: ${err.message}`);
    } finally {
      setIsFixing(false);
    }
  };

  // Insert ScreenGui converted script into StarterGui
  const handleInsertConvertedGui = (name: string, code: string) => {
    const newGuiFile: ProjectFile = {
      id: `gui-${Date.now()}`,
      name,
      type: "LocalScript",
      parentPath: "StarterGui",
      description: "ScreenGui responsive convertito da screenshot con Gemini 3.8 Vision",
      content: code,
      modifiedAt: Date.now(),
    };
    setFiles((prev) => [newGuiFile, ...prev]);
    setActiveFileId(newGuiFile.id);
    setActiveTab("editor");
    showToast(`UI '${name}' inserita in StarterGui!`);

    if (autoSyncEnabled) {
      pushFileToStudio(newGuiFile);
    }
  };

  // Insert Lighting FX Script
  const handleInsertLightingScript = (name: string, code: string) => {
    const newLightingFile: ProjectFile = {
      id: `lighting-${Date.now()}`,
      name,
      type: "Server",
      parentPath: "ServerScriptService",
      description: "Configurazione post-processing (Motion Blur, Depth of Field, Bloom)",
      content: code,
      modifiedAt: Date.now(),
    };
    setFiles((prev) => [newLightingFile, ...prev]);
    setActiveFileId(newLightingFile.id);
    setActiveTab("editor");
    showToast(`Script Lighting '${name}' inserito in ServerScriptService!`);

    if (autoSyncEnabled) {
      pushFileToStudio(newLightingFile);
    }
  };

  // Export all project files as a JSON manifest / multi-file text
  const handleExportAll = () => {
    const manifest = {
      name: "BloxGen Roblox Studio Project",
      exportedAt: new Date().toISOString(),
      generator: "Gemini 3.8 Flash Engine",
      files: files.map((f) => ({
        name: `${f.name}.luau`,
        type: f.type,
        parent: f.parentPath,
        content: f.content,
      })),
    };

    const blob = new Blob([JSON.stringify(manifest, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "bloxgen_roblox_project.json";
    link.click();
    URL.revokeObjectURL(url);
    showToast("Progetto esportato in formato JSON (compatibile con Rojo / Roblox Studio)!");
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-950 text-slate-100 overflow-hidden font-sans">
      {/* Top Application Header */}
      <Header
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onExportAll={handleExportAll}
        activeFileName={activeFile.name}
        activeFileCode={activeFile.content}
        isStudioConnected={isStudioConnected}
        studioPlaceName={studioPlaceName}
        onOpenTutorial={() => setIsGlobalTutorialOpen(true)}
      />

      {/* Main Workspace Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Roblox Explorer Sidebar */}
        <ExplorerSidebar
          files={files}
          activeFileId={activeFile.id}
          onSelectFile={(id) => {
            setActiveFileId(id);
            setActiveTab("editor");
          }}
          onCreateScript={handleCreateScript}
          onDeleteFile={handleDeleteFile}
          onPromptModify={(file) => {
            setActiveFileId(file.id);
            setActiveTab("editor");
          }}
        />

        {/* Dynamic Center Area based on activeTab */}
        <main className="flex-1 flex flex-col min-w-0 overflow-hidden bg-slate-950">
          {/* TAB 1: Luau Code Editor & Real-Time Debugger */}
          {activeTab === "editor" && (
            <div className="flex-1 flex flex-col p-3 space-y-3 overflow-y-auto">
              {/* AI Prompt Input Bar */}
              <AiPromptBar
                onGenerate={handleGenerateLua}
                isLoading={isGenerating}
                selectedScriptType={selectedScriptType}
                onChangeScriptType={setSelectedScriptType}
                activeFileName={activeFile.name}
              />

              {/* Real-time Syntax & Logic Debugger */}
              <RealtimeDebugger
                activeFile={activeFile}
                syntaxIssues={syntaxIssues}
                onApplyFixedCode={handleUpdateCode}
              />

              {/* Code Editor */}
              <LuaEditor
                file={activeFile}
                onChangeCode={handleUpdateCode}
                syntaxIssues={syntaxIssues}
                onTriggerAiFix={handleTriggerAiFix}
                onTriggerOptimize={() => setActiveTab("profiler")}
                isFixing={isFixing}
              />
            </div>
          )}

          {/* TAB 2: Roblox Studio Live Bridge & Remote Sync */}
          {activeTab === "studio-bridge" && (
            <RobloxStudioBridge
              files={files}
              activeFile={activeFile}
              onSelectFileByName={(name) => {
                const target = files.find((f) => f.name === name);
                if (target) {
                  setActiveFileId(target.id);
                  setActiveTab("editor");
                }
              }}
              onTriggerAiFixForError={(errorText) => {
                setActiveTab("editor");
                showToast(`Debug dell'errore di Studio inviato a Gemini 3.8: "${errorText.substring(0, 40)}..."`);
                handleTriggerAiFix();
              }}
            />
          )}

          {/* TAB 3: Screenshot to Roblox UI Vision Converter */}
          {activeTab === "ui-converter" && (
            <ScreenshotUiConverter onInsertToStarterGui={handleInsertConvertedGui} />
          )}

          {/* TAB 4: Graphic Asset Manager */}
          {activeTab === "assets" && (
            <AssetManager
              onInjectAssetToPrompt={(asset: GraphicAsset) => {
                setActiveTab("editor");
                showToast(`Asset '${asset.name}' aggiunto al generatore!`);
              }}
              onInsertCodeToActiveFile={(snippet: string) => {
                handleUpdateCode(activeFile.content + "\n\n" + snippet);
                setActiveTab("editor");
                showToast("Snippet dell'asset inserito nello script attivo!");
              }}
            />
          )}

          {/* TAB 5: Lighting & Post-Processing FX Studio */}
          {activeTab === "lighting-fx" && (
            <LightingFxStudio onInsertScriptToProject={handleInsertLightingScript} />
          )}

          {/* TAB 6: Luau Performance Profiler */}
          {activeTab === "profiler" && (
            <PerformanceOptimizer
              activeFile={activeFile}
              onApplyOptimizedCode={(code) => {
                handleUpdateCode(code);
                showToast("Codice ottimizzato applicato con successo!");
              }}
            />
          )}
        </main>
      </div>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-4 right-4 z-50 bg-slate-900 border border-slate-700 text-slate-100 text-xs px-4 py-2.5 rounded-lg shadow-xl flex items-center gap-2 animate-in fade-in slide-in-from-bottom-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Global Plugin Installation Tutorial Modal */}
      <PluginInstallTutorialModal
        isOpen={isGlobalTutorialOpen}
        onClose={() => setIsGlobalTutorialOpen(false)}
        isStudioConnected={isStudioConnected}
      />
    </div>
  );
}


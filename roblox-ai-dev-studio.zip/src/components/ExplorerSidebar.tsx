import React, { useState } from "react";
import { 
  Folder, 
  FileCode, 
  Plus, 
  Trash2, 
  ChevronRight, 
  ChevronDown, 
  Sparkles, 
  Sun, 
  Box, 
  Users, 
  Monitor, 
  Cpu, 
  Database,
  Search
} from "lucide-react";
import { ProjectFile, ScriptType } from "../types";

interface ExplorerSidebarProps {
  files: ProjectFile[];
  activeFileId: string;
  onSelectFile: (id: string) => void;
  onCreateScript: (parent: string, type: ScriptType, name: string) => void;
  onDeleteFile: (id: string) => void;
  onPromptModify: (file: ProjectFile) => void;
}

const ROBLOX_SERVICES = [
  { name: "Workspace", icon: Box, color: "text-amber-400" },
  { name: "Lighting", icon: Sun, color: "text-yellow-400" },
  { name: "ReplicatedStorage", icon: Database, color: "text-blue-400" },
  { name: "ServerScriptService", icon: Cpu, color: "text-emerald-400" },
  { name: "ServerStorage", icon: Database, color: "text-slate-400" },
  { name: "StarterGui", icon: Monitor, color: "text-violet-400" },
  { name: "StarterPlayer", icon: Users, color: "text-teal-400" },
];

export const ExplorerSidebar: React.FC<ExplorerSidebarProps> = ({
  files,
  activeFileId,
  onSelectFile,
  onCreateScript,
  onDeleteFile,
  onPromptModify,
}) => {
  const [collapsedServices, setCollapsedServices] = useState<Record<string, boolean>>({});
  const [newScriptParent, setNewScriptParent] = useState<string | null>(null);
  const [newScriptName, setNewScriptName] = useState("");
  const [newScriptType, setNewScriptType] = useState<ScriptType>("Server");
  const [searchQuery, setSearchQuery] = useState("");

  const toggleService = (name: string) => {
    setCollapsedServices((prev) => ({ ...prev, [name]: !prev[name] }));
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newScriptParent || !newScriptName.trim()) return;
    onCreateScript(newScriptParent, newScriptType, newScriptName.trim());
    setNewScriptParent(null);
    setNewScriptName("");
  };

  const filteredFiles = searchQuery.trim()
    ? files.filter((f) => f.name.toLowerCase().includes(searchQuery.toLowerCase()))
    : files;

  return (
    <aside className="w-64 bg-slate-950 border-r border-slate-800 flex flex-col h-full select-none text-xs">
      {/* Explorer Header */}
      <div className="p-3 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2 font-semibold text-slate-200">
          <Folder className="w-4 h-4 text-amber-500" />
          <span>Explorer</span>
        </div>
        <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded font-mono">
          {files.length} Script
        </span>
      </div>

      {/* Filter Search */}
      <div className="px-2.5 py-2 border-b border-slate-800/80">
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2 top-2 text-slate-500" />
          <input
            type="text"
            placeholder="Cerca script o istanze..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded pl-7 pr-2 py-1 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-red-500"
          />
        </div>
      </div>

      {/* Service Tree */}
      <div className="flex-1 overflow-y-auto p-1.5 space-y-1">
        {ROBLOX_SERVICES.map((srv) => {
          const srvFiles = filteredFiles.filter((f) => f.parentPath === srv.name);
          const isCollapsed = Boolean(collapsedServices[srv.name]);
          const Icon = srv.icon;

          return (
            <div key={srv.name} className="rounded overflow-hidden">
              <div
                className="flex items-center justify-between px-2 py-1 hover:bg-slate-900/80 rounded cursor-pointer group text-slate-300"
                onClick={() => toggleService(srv.name)}
              >
                <div className="flex items-center gap-1.5 min-w-0">
                  {isCollapsed ? (
                    <ChevronRight className="w-3 h-3 text-slate-500 flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-3 h-3 text-slate-500 flex-shrink-0" />
                  )}
                  <Icon className={`w-3.5 h-3.5 ${srv.color} flex-shrink-0`} />
                  <span className="truncate font-medium text-slate-300">{srv.name}</span>
                </div>

                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setNewScriptParent(srv.name);
                      setNewScriptName("");
                      setNewScriptType(
                        srv.name === "StarterGui" || srv.name === "StarterPlayer"
                          ? "LocalScript"
                          : srv.name === "ReplicatedStorage"
                          ? "ModuleScript"
                          : "Server"
                      );
                    }}
                    className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white"
                    title={`Aggiungi script in ${srv.name}`}
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* Service Files */}
              {!isCollapsed && (
                <div className="pl-4 space-y-0.5 mt-0.5 border-l border-slate-800/60 ml-3">
                  {srvFiles.length === 0 ? (
                    <div className="text-[10px] text-slate-600 px-2 py-0.5 italic">
                      Nessun script
                    </div>
                  ) : (
                    srvFiles.map((file) => {
                      const isActive = file.id === activeFileId;
                      return (
                        <div
                          key={file.id}
                          onClick={() => onSelectFile(file.id)}
                          className={`group flex items-center justify-between px-2 py-1 rounded cursor-pointer transition-colors ${
                            isActive
                              ? "bg-red-600/20 text-red-300 border border-red-500/30"
                              : "hover:bg-slate-900 text-slate-400 hover:text-slate-200"
                          }`}
                        >
                          <div className="flex items-center gap-1.5 min-w-0">
                            <FileCode
                              className={`w-3.5 h-3.5 flex-shrink-0 ${
                                file.type === "Server"
                                  ? "text-emerald-400"
                                  : file.type === "LocalScript"
                                  ? "text-blue-400"
                                  : "text-amber-400"
                              }`}
                            />
                            <span className="truncate">{file.name}</span>
                          </div>

                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onPromptModify(file);
                              }}
                              className="p-0.5 hover:text-red-400 text-slate-500"
                              title="Modifica con Prompt Gemini 3.8"
                            >
                              <Sparkles className="w-3 h-3" />
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onDeleteFile(file.id);
                              }}
                              className="p-0.5 hover:text-rose-400 text-slate-500"
                              title="Elimina script"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* New Script Inline Form */}
      {newScriptParent && (
        <form
          onSubmit={handleCreateSubmit}
          className="p-3 border-t border-slate-800 bg-slate-900/90 space-y-2"
        >
          <div className="text-[11px] font-medium text-slate-300 flex items-center justify-between">
            <span>Nuovo Script in {newScriptParent}</span>
            <button
              type="button"
              onClick={() => setNewScriptParent(null)}
              className="text-slate-500 hover:text-slate-300"
            >
              ✕
            </button>
          </div>

          <input
            type="text"
            placeholder="NomeScript"
            value={newScriptName}
            onChange={(e) => setNewScriptName(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-200 focus:outline-none focus:border-red-500"
            autoFocus
          />

          <div className="flex gap-1 text-[10px]">
            {(["Server", "LocalScript", "ModuleScript"] as ScriptType[]).map((t) => (
              <button
                type="button"
                key={t}
                onClick={() => setNewScriptType(t)}
                className={`flex-1 py-1 rounded border text-center transition-colors ${
                  newScriptType === t
                    ? "bg-red-600 text-white border-red-500"
                    : "bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700"
                }`}
              >
                {t === "Server" ? "Server" : t === "LocalScript" ? "Local" : "Module"}
              </button>
            ))}
          </div>

          <button
            type="submit"
            disabled={!newScriptName.trim()}
            className="w-full py-1 bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white rounded font-medium text-xs transition-colors"
          >
            Crea Script
          </button>
        </form>
      )}
    </aside>
  );
};

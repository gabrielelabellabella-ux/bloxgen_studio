import React, { useState, useRef } from "react";
import { 
  Upload, 
  Sparkles, 
  Layers, 
  Smartphone, 
  Monitor, 
  Tablet, 
  Tv, 
  RotateCw, 
  Check, 
  Copy, 
  FileCode, 
  Loader2, 
  Info,
  Maximize2,
  Eye
} from "lucide-react";
import { DevicePreset, UiElementData } from "../types";
import { DEFAULT_DEVICE_PRESETS } from "../utils/defaultProject";

interface ScreenshotUiConverterProps {
  onInsertToStarterGui: (name: string, code: string) => void;
}

export const ScreenshotUiConverter: React.FC<ScreenshotUiConverterProps> = ({
  onInsertToStarterGui,
}) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [mimeType, setMimeType] = useState<string>("image/png");
  const [instructions, setInstructions] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // AI Conversion Output
  const [conversionResult, setConversionResult] = useState<{
    uiTitle: string;
    colorPalette: string[];
    componentsCount: number;
    responsiveAdvice: string;
    elements: UiElementData[];
    luauCode: string;
  } | null>(null);

  // Device Emulation State
  const [selectedDevice, setSelectedDevice] = useState<DevicePreset>(DEFAULT_DEVICE_PRESETS[0]);
  const [isPortrait, setIsPortrait] = useState(false);
  const [activeTab, setActiveTab] = useState<"preview" | "code">("preview");
  const [copiedCode, setCopiedCode] = useState(false);
  const [inserted, setInserted] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setMimeType(file.type || "image/png");
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setSelectedImage(event.target.result as string);
        setConversionResult(null);
        setErrorMsg(null);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleConvert = async () => {
    if (!selectedImage) return;
    setIsLoading(true);
    setErrorMsg(null);

    try {
      const res = await fetch("/api/gemini/convert-ui", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: selectedImage,
          mimeType,
          instructions,
          targetDevice: selectedDevice.name,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || "Conversione fallita");
      }

      setConversionResult(data);
      setActiveTab("preview");
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "Errore durante l'analisi visiva dello screenshot.");
    } finally {
      setIsLoading(false);
    }
  };

  // Sample screenshot mock generator
  const loadDemoScreenshot = (type: "hud" | "shop") => {
    const canvas = document.createElement("canvas");
    canvas.width = 800;
    canvas.height = 450;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    if (type === "hud") {
      // Dark gradient background
      const bg = ctx.createLinearGradient(0, 0, 0, 450);
      bg.addColorStop(0, "#0b0f19");
      bg.addColorStop(1, "#1a1f35");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, 800, 450);

      // Top bar
      ctx.fillStyle = "#161b2e";
      ctx.fillRect(20, 20, 260, 60);
      ctx.fillStyle = "#ef4444";
      ctx.fillRect(30, 30, 180, 18);
      ctx.fillStyle = "#3b82f6";
      ctx.fillRect(30, 52, 140, 14);
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 13px sans-serif";
      ctx.fillText("HP: 100/100", 220, 44);

      // Hotbar bottom
      ctx.fillStyle = "#1e243b";
      ctx.roundRect?.(250, 370, 300, 60, 12);
      ctx.fill();
      for (let i = 0; i < 5; i++) {
        ctx.fillStyle = "#2d3554";
        ctx.fillRect(265 + i * 55, 380, 42, 42);
        ctx.fillStyle = "#94a3b8";
        ctx.font = "bold 12px sans-serif";
        ctx.fillText(`${i + 1}`, 272 + i * 55, 405);
      }
    } else {
      // Shop UI Mockup
      ctx.fillStyle = "#0f172a";
      ctx.fillRect(0, 0, 800, 450);
      ctx.fillStyle = "#1e293b";
      ctx.roundRect?.(150, 50, 500, 350, 16);
      ctx.fill();
      ctx.fillStyle = "#38bdf8";
      ctx.font = "bold 20px sans-serif";
      ctx.fillText("SHOP DELLE ARMI", 300, 95);

      // 4 item cards
      for (let r = 0; r < 2; r++) {
        for (let c = 0; c < 2; c++) {
          ctx.fillStyle = "#334155";
          ctx.roundRect?.(190 + c * 220, 130 + r * 120, 200, 100, 10);
          ctx.fill();
          ctx.fillStyle = "#22c55e";
          ctx.font = "bold 14px sans-serif";
          ctx.fillText("500 Monete", 210 + c * 220, 210 + r * 120);
        }
      }
    }

    const dataUrl = canvas.toDataURL("image/png");
    setSelectedImage(dataUrl);
    setMimeType("image/png");
    setConversionResult(null);
  };

  const handleCopyCode = () => {
    if (conversionResult?.luauCode) {
      navigator.clipboard.writeText(conversionResult.luauCode);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    }
  };

  const handleInsert = () => {
    if (conversionResult?.luauCode) {
      const name = conversionResult.uiTitle.replace(/\s+/g, "") || "ConvertedScreenGui";
      onInsertToStarterGui(name, conversionResult.luauCode);
      setInserted(true);
      setTimeout(() => setInserted(false), 3000);
    }
  };

  // Compute emulator dimensions
  const deviceWidth = isPortrait ? selectedDevice.height : selectedDevice.width;
  const deviceHeight = isPortrait ? selectedDevice.width : selectedDevice.height;

  return (
    <div className="flex-1 flex flex-col bg-slate-950 p-4 overflow-y-auto space-y-4">
      {/* Title & Explanatory Banner */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-red-500" />
            <h2 className="text-base font-semibold text-slate-100">
              Screenshot to Roblox UI Converter (Vision Multimodal)
            </h2>
            <span className="text-[10px] bg-red-500/20 text-red-300 font-mono px-2 py-0.5 rounded border border-red-500/30">
              Gemini 3.8 Vision
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Invia uno screenshot o mockup della tua interfaccia di gioco: Gemini 3.8 analizzerà forme,
            colori, font e layout, convertendoli automaticamente in elementi grafici nativi Roblox (ScreenGui,
            Frame, TextLabel, ImageButton, UICorner, UIStroke) con scalatura UDim2.fromScale per una perfetta
            responsività su ogni schermo.
          </p>
        </div>

        {/* Quick Demo Buttons */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-500 text-[11px]">Prova demo:</span>
          <button
            onClick={() => loadDemoScreenshot("hud")}
            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 text-xs transition-colors"
          >
            HUD Giocatore
          </button>
          <button
            onClick={() => loadDemoScreenshot("shop")}
            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 text-xs transition-colors"
          >
            Menù Shop
          </button>
        </div>
      </div>

      {/* Grid: Upload & Instructions (Left) vs Converted Output (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Upload & Options */}
        <div className="lg:col-span-4 space-y-3">
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3">
            <label className="block text-xs font-semibold text-slate-200">
              1. Carica Screenshot UI o Mockup
            </label>

            {/* Dropzone */}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept="image/*"
              className="hidden"
            />
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-800 hover:border-red-500/60 bg-slate-950/60 rounded-lg p-4 flex flex-col items-center justify-center cursor-pointer transition-colors text-center group"
            >
              {selectedImage ? (
                <div className="space-y-2 w-full">
                  <img
                    src={selectedImage}
                    alt="Screenshot Caricato"
                    className="max-h-44 mx-auto rounded border border-slate-800 object-contain shadow"
                  />
                  <p className="text-[11px] text-slate-400 group-hover:text-slate-200">
                    Clicca per cambiare screenshot
                  </p>
                </div>
              ) : (
                <div className="space-y-2 py-4">
                  <div className="w-10 h-10 rounded-full bg-red-500/10 text-red-400 flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
                    <Upload className="w-5 h-5" />
                  </div>
                  <div className="text-xs text-slate-300 font-medium">
                    Trascina o clicca per caricare
                  </div>
                  <p className="text-[11px] text-slate-500">
                    PNG, JPG, WebP da Roblox Studio o bozze grafiche
                  </p>
                </div>
              )}
            </div>

            {/* Custom Instructions */}
            <div className="space-y-1">
              <label className="text-[11px] font-medium text-slate-300 flex items-center justify-between">
                <span>Istruzioni aggiuntive (opzionali):</span>
              </label>
              <textarea
                rows={2}
                value={instructions}
                onChange={(e) => setInstructions(e.target.value)}
                placeholder="Es: Rendi i pulsanti arrotondati con UICorner raggio 16, aggiungi UIStroke dorato e garantisci che il menù rimanga centrato su smartphone..."
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-red-500 resize-none"
              />
            </div>

            {/* Convert Button */}
            <button
              onClick={handleConvert}
              disabled={!selectedImage || isLoading}
              className="w-full py-2 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 disabled:opacity-50 text-white font-semibold rounded-md text-xs shadow flex items-center justify-center gap-2 transition-all active:scale-95"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Gemini 3.8 Analisi Vision in corso...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Converti Screenshot in Elementi Roblox</span>
                </>
              )}
            </button>

            {errorMsg && (
              <div className="p-2.5 rounded bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
                {errorMsg}
              </div>
            )}
          </div>

          {/* Palette & Analysis Notes */}
          {conversionResult && (
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-2.5 text-xs">
              <h3 className="font-semibold text-slate-200 flex items-center justify-between">
                <span>Analisi Visiva Rilevata</span>
                <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded">
                  {conversionResult.componentsCount} elementi
                </span>
              </h3>

              <div className="space-y-1">
                <span className="text-[11px] text-slate-400">Palette Colori Riconosciuta:</span>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {conversionResult.colorPalette?.map((c, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-950 border border-slate-800 text-[10px] font-mono text-slate-300"
                    >
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: c }}></span>
                      <span>{c}</span>
                    </div>
                  ))}
                </div>
              </div>

              {conversionResult.responsiveAdvice && (
                <div className="p-2 bg-slate-950 rounded border border-slate-800/80 text-[11px] text-slate-300 space-y-1">
                  <div className="font-medium text-amber-400 flex items-center gap-1">
                    <Info className="w-3 h-3" /> Regole di Scaling Applicate:
                  </div>
                  <p className="text-slate-400 leading-relaxed">
                    {conversionResult.responsiveAdvice}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right Column: Emulator & Code View */}
        <div className="lg:col-span-8 flex flex-col bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
          {/* Emulator Top Controls */}
          <div className="bg-slate-900/90 border-b border-slate-800 p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
            {/* Tab Switcher */}
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded border border-slate-800">
              <button
                onClick={() => setActiveTab("preview")}
                className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium transition-all ${
                  activeTab === "preview"
                    ? "bg-red-600 text-white"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Anteprima Responsive</span>
              </button>
              <button
                onClick={() => setActiveTab("code")}
                className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium transition-all ${
                  activeTab === "code"
                    ? "bg-red-600 text-white"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                <FileCode className="w-3.5 h-3.5" />
                <span>Script Luau ({conversionResult?.uiTitle || "ScreenGui"})</span>
              </button>
            </div>

            {/* Device Selector for Responsiveness Test */}
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 bg-slate-950 px-2 py-1 rounded border border-slate-800 text-[11px]">
                {DEFAULT_DEVICE_PRESETS.map((dev) => {
                  const Icon =
                    dev.category === "Mobile"
                      ? Smartphone
                      : dev.category === "Tablet"
                      ? Tablet
                      : dev.category === "Console"
                      ? Tv
                      : Monitor;
                  return (
                    <button
                      key={dev.id}
                      onClick={() => setSelectedDevice(dev)}
                      className={`p-1 rounded flex items-center gap-1 transition-colors ${
                        selectedDevice.id === dev.id
                          ? "bg-red-600 text-white font-semibold"
                          : "text-slate-400 hover:text-slate-200"
                      }`}
                      title={`${dev.name} (${dev.width}x${dev.height})`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span className="hidden md:inline">{dev.name.split(" ")[0]}</span>
                    </button>
                  );
                })}

                <button
                  onClick={() => setIsPortrait(!isPortrait)}
                  className={`p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 ml-1 ${
                    isPortrait ? "text-amber-400" : ""
                  }`}
                  title="Ruota Orientamento (Landscape / Portrait)"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                </button>
              </div>

              {conversionResult && (
                <button
                  onClick={handleInsert}
                  className="flex items-center gap-1 px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded text-xs shadow transition-colors"
                >
                  {inserted ? <Check className="w-3.5 h-3.5" /> : <Layers className="w-3.5 h-3.5" />}
                  <span>{inserted ? "Inserito in StarterGui!" : "Inserisci nel Progetto"}</span>
                </button>
              )}
            </div>
          </div>

          {/* Tab 1: Interactive Live Responsive Canvas Preview */}
          {activeTab === "preview" && (
            <div className="flex-1 bg-slate-950 p-4 min-h-[460px] flex flex-col items-center justify-center overflow-auto relative">
              {conversionResult ? (
                <div className="w-full flex flex-col items-center space-y-2">
                  <div className="text-[11px] text-slate-400 flex items-center gap-3">
                    <span>Emulatore: <strong className="text-slate-200">{selectedDevice.name}</strong></span>
                    <span>Risoluzione: <strong className="text-slate-200">{deviceWidth} × {deviceHeight}</strong> ({selectedDevice.aspectRatioLabel})</span>
                    <span className="text-emerald-400">Scale: UDim2.fromScale()</span>
                  </div>

                  {/* Device Screen Frame with scaled viewport */}
                  <div
                    className="relative bg-slate-900 border-4 border-slate-800 rounded-xl overflow-hidden shadow-2xl transition-all duration-300"
                    style={{
                      width: "100%",
                      maxWidth: isPortrait ? "360px" : "680px",
                      aspectRatio: `${deviceWidth} / ${deviceHeight}`,
                    }}
                  >
                    {/* Roblox ScreenGui Background Game Simulation */}
                    <div className="absolute inset-0 bg-gradient-to-b from-sky-900/30 via-slate-900/60 to-slate-950 flex items-center justify-center pointer-events-none">
                      <span className="text-slate-700 font-bold text-xs tracking-widest uppercase select-none">
                        Viewport 3D Roblox Game
                      </span>
                    </div>

                    {/* Render Converted UI Elements */}
                    {conversionResult.elements?.map((el, i) => (
                      <div
                        key={el.id || i}
                        className="absolute flex items-center justify-center text-center select-none transition-transform hover:scale-[1.01] group cursor-pointer"
                        style={{
                          left: `${(el.position?.xScale ?? 0.5) * 100}%`,
                          top: `${(el.position?.yScale ?? 0.5) * 100}%`,
                          width: `${(el.size?.xScale ?? 0.3) * 100}%`,
                          height: `${(el.size?.yScale ?? 0.1) * 100}%`,
                          transform: `translate(-${(el.anchorPoint?.x ?? 0.5) * 100}%, -${(el.anchorPoint?.y ?? 0.5) * 100}%)`,
                          backgroundColor: el.backgroundColor || "#1e293b",
                          opacity: 1 - (el.backgroundTransparency ?? 0),
                          borderRadius: `${el.cornerRadius || 8}px`,
                          border: el.strokeColor ? `${el.strokeThickness || 2}px solid ${el.strokeColor}` : "1px solid rgba(255,255,255,0.1)",
                          color: el.textColor || "#ffffff",
                        }}
                        title={`Roblox Element: ${el.name} (${el.type})`}
                      >
                        <span className="text-xs font-semibold px-2 truncate pointer-events-none">
                          {el.text || el.name}
                        </span>

                        {/* Hover Inspector Tooltip */}
                        <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -bottom-7 bg-slate-900 text-[10px] text-slate-300 font-mono px-2 py-0.5 rounded shadow border border-slate-700 pointer-events-none z-30 whitespace-nowrap">
                          {el.type}: {el.name} (UDim2 Scale)
                        </div>
                      </div>
                    ))}
                  </div>

                  <p className="text-[11px] text-slate-500 italic text-center">
                    Gli elementi mantengono la loro posizione e scala relative al viewport, garantendo
                    responsività su PC, Console, Tablet e Smartphone.
                  </p>
                </div>
              ) : (
                <div className="text-center space-y-3 p-8 text-slate-500">
                  <div className="w-14 h-14 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto text-slate-400">
                    <Layers className="w-7 h-7" />
                  </div>
                  <div className="text-sm font-semibold text-slate-300">
                    Nessuna interfaccia analizzata al momento
                  </div>
                  <p className="text-xs text-slate-500 max-w-md mx-auto">
                    Carica uno screenshot a sinistra o clicca su uno dei bottoni demo ("HUD Giocatore" o "Menù Shop")
                    per avviare la conversione con Gemini 3.8.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Tab 2: Generated Luau Code View */}
          {activeTab === "code" && (
            <div className="flex-1 bg-slate-950 p-3 overflow-auto flex flex-col font-mono text-xs">
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
                <span className="text-slate-400 text-[11px]">
                  Codice Luau pronto da inserire in StarterGui / LocalScript
                </span>
                <button
                  onClick={handleCopyCode}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode ? "Copiato!" : "Copia Codice"}</span>
                </button>
              </div>

              <pre className="text-slate-300 leading-relaxed whitespace-pre overflow-auto flex-1 font-mono text-xs">
                {conversionResult?.luauCode || "-- Nessun codice generato. Avvia la conversione dello screenshot."}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

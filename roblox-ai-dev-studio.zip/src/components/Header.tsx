import React, { useState, useEffect } from "react";
import { 
  Terminal, 
  Sparkles, 
  Image as ImageIcon, 
  Sliders, 
  Gauge, 
  Download, 
  Check, 
  Copy,
  Layers,
  Radio,
  BookOpen,
  Volume2,
  VolumeX
} from "lucide-react";
import confetti from "canvas-confetti";
import { sfx } from "../utils/soundEffects";

interface HeaderProps {
  activeTab: "editor" | "ui-converter" | "assets" | "lighting-fx" | "profiler" | "studio-bridge";
  onTabChange: (tab: "editor" | "ui-converter" | "assets" | "lighting-fx" | "profiler" | "studio-bridge") => void;
  onExportAll: () => void;
  activeFileName?: string;
  activeFileCode?: string;
  isStudioConnected?: boolean;
  studioPlaceName?: string;
  onOpenTutorial?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onTabChange,
  onExportAll,
  activeFileName,
  activeFileCode,
  isStudioConnected = false,
  studioPlaceName,
  onOpenTutorial,
}) => {
  const [copied, setCopied] = useState(false);
  const [isMuted, setIsMuted] = useState(sfx.getMuted());

  const handleCopyCurrent = () => {
    if (activeFileCode) {
      navigator.clipboard.writeText(activeFileCode);
      sfx.playPop();
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleTabClick = (tab: "editor" | "ui-converter" | "assets" | "lighting-fx" | "profiler" | "studio-bridge") => {
    sfx.playClick();
    onTabChange(tab);
  };

  const handleToggleMute = () => {
    const muted = sfx.toggleMute();
    setIsMuted(muted);
  };

  const handleExportWithConfetti = () => {
    sfx.playSuccess();
    try {
      confetti({
        particleCount: 40,
        spread: 55,
        origin: { y: 0.6 },
        colors: ["#ef4444", "#10b981", "#3b82f6", "#f59e0b"],
      });
    } catch (e) {
      // ignore
    }
    onExportAll();
  };

  return (
    <header className="bg-slate-900/95 backdrop-blur-md border-b border-slate-800/80 px-4 py-2 flex flex-wrap items-center justify-between gap-3 select-none">
      {/* Brand & Studio Title */}
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-rose-500 via-red-500 to-amber-500 flex items-center justify-center shadow-lg shadow-red-500/20 text-white font-black tracking-wider text-sm transition-transform hover:scale-105">
          RBLX
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-sm font-bold text-slate-100 tracking-tight">
              BloxGen Studio
            </h1>
            <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1 shadow-sm">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              Gemini 3.8 Active
            </span>
          </div>
          <p className="text-[11px] text-slate-400 hidden sm:block">
            Roblox Studio Live Sync • Luau AI • ScreenGui Vision • Lighting FX
          </p>
        </div>
      </div>

      {/* Main Workflow Navigation Tabs */}
      <nav className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800/80 shadow-inner">
        <button
          onClick={() => handleTabClick("editor")}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            activeTab === "editor"
              ? "bg-red-600 text-white shadow-md shadow-red-600/30 scale-100"
              : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
          }`}
        >
          <Terminal className="w-3.5 h-3.5" />
          <span>Editor Luau</span>
        </button>

        {/* Dedicated Roblox Studio Bridge Tab */}
        <button
          onClick={() => handleTabClick("studio-bridge")}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all relative ${
            activeTab === "studio-bridge"
              ? "bg-red-600 text-white shadow-md shadow-red-600/30"
              : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
          }`}
        >
          <Radio className={`w-3.5 h-3.5 ${isStudioConnected ? "text-emerald-400 animate-pulse" : ""}`} />
          <span>Studio Bridge</span>
          <span
            className={`w-2 h-2 rounded-full ${
              isStudioConnected ? "bg-emerald-400 shadow-sm shadow-emerald-400 animate-ping" : "bg-rose-500"
            }`}
          />
        </button>

        <button
          onClick={() => handleTabClick("ui-converter")}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            activeTab === "ui-converter"
              ? "bg-red-600 text-white shadow-md shadow-red-600/30"
              : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Screenshot to UI</span>
        </button>

        <button
          onClick={() => handleTabClick("assets")}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            activeTab === "assets"
              ? "bg-red-600 text-white shadow-md shadow-red-600/30"
              : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
          }`}
        >
          <ImageIcon className="w-3.5 h-3.5" />
          <span>Asset Manager</span>
        </button>

        <button
          onClick={() => handleTabClick("lighting-fx")}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            activeTab === "lighting-fx"
              ? "bg-red-600 text-white shadow-md shadow-red-600/30"
              : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Lighting & FX</span>
        </button>

        <button
          onClick={() => handleTabClick("profiler")}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            activeTab === "profiler"
              ? "bg-red-600 text-white shadow-md shadow-red-600/30"
              : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
          }`}
        >
          <Gauge className="w-3.5 h-3.5" />
          <span>Profiler</span>
        </button>
      </nav>

      {/* Live Status Pill & Quick Action Buttons */}
      <div className="flex items-center gap-2">
        {/* Tutorial Button */}
        {onOpenTutorial && (
          <button
            onClick={() => {
              sfx.playClick();
              onOpenTutorial();
            }}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 transition-all active:scale-95 shadow-sm"
            title="Guida passo-passo per installare il plugin in modo permanente in Roblox Studio"
          >
            <BookOpen className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Tutorial Plugin</span>
          </button>
        )}

        {/* Audio SFX Toggle */}
        <button
          onClick={handleToggleMute}
          className={`p-1.5 rounded-lg border text-xs transition-colors ${
            !isMuted 
              ? "bg-slate-800/90 border-slate-700 text-slate-200 hover:text-white" 
              : "bg-slate-900 border-slate-800 text-slate-500 hover:text-slate-400"
          }`}
          title={isMuted ? "Attiva effetti sonori studio" : "Disattiva effetti sonori studio"}
        >
          {!isMuted ? <Volume2 className="w-3.5 h-3.5 text-emerald-400" /> : <VolumeX className="w-3.5 h-3.5" />}
        </button>

        {/* Studio Connection Status Pill */}
        <button
          onClick={() => handleTabClick("studio-bridge")}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border transition-all cursor-pointer shadow-sm ${
            isStudioConnected
              ? "bg-emerald-500/15 border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/25 shadow-emerald-500/10"
              : "bg-rose-500/10 border-rose-500/30 text-rose-300 hover:bg-rose-500/20"
          }`}
          title={isStudioConnected ? `Connesso al posto: ${studioPlaceName}` : "Clicca per collegare Roblox Studio"}
        >
          <span
            className={`w-2 h-2 rounded-full ${
              isStudioConnected ? "bg-emerald-400 animate-pulse" : "bg-rose-400"
            }`}
          />
          <span className="text-[11px] font-mono font-medium">
            {isStudioConnected ? "Roblox Studio Connesso" : "Collega Roblox Studio"}
          </span>
        </button>

        {activeFileCode && (
          <button
            onClick={handleCopyCurrent}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 rounded-lg transition-colors"
            title="Copia codice dello script attivo"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span className="hidden md:inline">{copied ? "Copiato!" : "Copia Script"}</span>
          </button>
        )}

        <button
          onClick={handleExportWithConfetti}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 rounded-lg shadow-lg shadow-red-600/20 transition-all transform active:scale-95"
          title="Esporta tutti gli script Luau e configurazioni Roblox"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Esporta Progetto</span>
        </button>
      </div>
    </header>
  );
};

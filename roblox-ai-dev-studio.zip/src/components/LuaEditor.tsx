import React, { useState, useRef, useEffect } from "react";
import { 
  Copy, 
  Check, 
  Download, 
  Wand2, 
  AlertTriangle, 
  AlertCircle, 
  Gauge, 
  Maximize2, 
  Minimize2,
  FileCode
} from "lucide-react";
import { ProjectFile, SyntaxIssue } from "../types";
import { tokenizeLuauLine, HighlightToken } from "../utils/luauParser";

interface LuaEditorProps {
  file: ProjectFile;
  onChangeCode: (newCode: string) => void;
  syntaxIssues: SyntaxIssue[];
  onTriggerAiFix: () => void;
  onTriggerOptimize: () => void;
  isFixing?: boolean;
}

export const LuaEditor: React.FC<LuaEditorProps> = ({
  file,
  onChangeCode,
  syntaxIssues,
  onTriggerAiFix,
  onTriggerOptimize,
  isFixing,
}) => {
  const [copied, setCopied] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const preRef = useRef<HTMLPreElement>(null);

  const errorCount = syntaxIssues.filter((i) => i.severity === "error").length;
  const warningCount = syntaxIssues.filter((i) => i.severity === "warning").length;

  const syncScroll = () => {
    if (textareaRef.current && preRef.current) {
      preRef.current.scrollTop = textareaRef.current.scrollTop;
      preRef.current.scrollLeft = textareaRef.current.scrollLeft;
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(file.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([file.content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${file.name}.luau`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const lines = file.content.split("\n");

  return (
    <div
      className={`flex flex-col bg-slate-950 border border-slate-800 rounded-lg overflow-hidden transition-all ${
        isFullscreen ? "fixed inset-2 z-50 shadow-2xl" : "flex-1 min-h-[450px]"
      }`}
    >
      {/* Editor Header Bar */}
      <div className="bg-slate-900/90 border-b border-slate-800 px-3 py-2 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2 min-w-0">
          <FileCode
            className={`w-4 h-4 flex-shrink-0 ${
              file.type === "Server"
                ? "text-emerald-400"
                : file.type === "LocalScript"
                ? "text-blue-400"
                : "text-amber-400"
            }`}
          />
          <span className="font-semibold text-slate-200 truncate">{file.name}.luau</span>
          <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded font-mono">
            {file.parentPath}
          </span>
          <span className="text-[10px] text-slate-500 font-mono hidden sm:inline">
            ({file.type})
          </span>
        </div>

        <div className="flex items-center gap-2">
          {errorCount > 0 && (
            <button
              onClick={onTriggerAiFix}
              disabled={isFixing}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 font-medium transition-colors disabled:opacity-50 text-[11px]"
              title="Risolvi errori di sintassi istantaneamente con Gemini 3.8"
            >
              <Wand2 className="w-3.5 h-3.5 animate-pulse" />
              <span>{isFixing ? "Risoluzione in corso..." : "Auto-Fix AI"}</span>
            </button>
          )}

          <button
            onClick={onTriggerOptimize}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-[11px] font-medium transition-colors"
            title="Ottimizza le prestazioni e previeni lag del Garbage Collector"
          >
            <Gauge className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Ottimizza</span>
          </button>

          <button
            onClick={handleCopy}
            className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800"
            title="Copia codice"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>

          <button
            onClick={handleDownload}
            className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800"
            title="Scarica file .luau"
          >
            <Download className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800"
            title={isFullscreen ? "Riduci editor" : "Espandi a schermo intero"}
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Editor Body */}
      <div className="relative flex-1 min-h-[300px] overflow-hidden flex font-mono text-xs">
        {/* Line Numbers & Issue Markers */}
        <div className="w-12 bg-slate-950 border-r border-slate-900 py-3 text-right pr-2 text-slate-600 select-none flex flex-col font-mono text-[11px]">
          {lines.map((_, i) => {
            const lineNum = i + 1;
            const lineIssue = syntaxIssues.find((issue) => issue.line === lineNum);
            return (
              <div key={lineNum} className="h-5 flex items-center justify-end gap-1 leading-5">
                {lineIssue && (
                  <span title={`${lineIssue.message}\n${lineIssue.suggestion || ""}`}>
                    {lineIssue.severity === "error" ? (
                      <AlertCircle className="w-2.5 h-2.5 text-rose-500 inline" />
                    ) : (
                      <AlertTriangle className="w-2.5 h-2.5 text-amber-500 inline" />
                    )}
                  </span>
                )}
                <span className={lineIssue ? (lineIssue.severity === "error" ? "text-rose-400 font-bold" : "text-amber-400") : ""}>
                  {lineNum}
                </span>
              </div>
            );
          })}
        </div>

        {/* Highlight Layer & Textarea */}
        <div className="relative flex-1 h-full overflow-hidden bg-slate-950">
          {/* Syntax Highlighted Background */}
          <pre
            ref={preRef}
            aria-hidden="true"
            className="absolute inset-0 m-0 py-3 px-3 overflow-hidden pointer-events-none whitespace-pre font-mono text-xs leading-5"
          >
            {lines.map((line, i) => {
              const tokens = tokenizeLuauLine(line);
              return (
                <div key={i} className="h-5 whitespace-pre">
                  {tokens.map((tok, tIdx) => {
                    let color = "text-slate-300";
                    if (tok.type === "keyword") color = "text-purple-400 font-semibold";
                    else if (tok.type === "builtin") color = "text-cyan-400 font-medium";
                    else if (tok.type === "string") color = "text-emerald-300";
                    else if (tok.type === "comment") color = "text-slate-500 italic";
                    else if (tok.type === "number") color = "text-amber-300";
                    else if (tok.type === "operator") color = "text-rose-400";

                    return (
                      <span key={tIdx} className={color}>
                        {tok.text}
                      </span>
                    );
                  })}
                  {tokens.length === 0 && <span> </span>}
                </div>
              );
            })}
          </pre>

          {/* Interactive Editable Input */}
          <textarea
            ref={textareaRef}
            value={file.content}
            onChange={(e) => onChangeCode(e.target.value)}
            onScroll={syncScroll}
            spellCheck={false}
            autoCapitalize="off"
            autoComplete="off"
            className="absolute inset-0 w-full h-full py-3 px-3 bg-transparent text-transparent caret-white selection:bg-red-600/30 font-mono text-xs leading-5 resize-none border-none outline-none overflow-auto whitespace-pre z-10"
          />
        </div>
      </div>

      {/* Editor Status Footer */}
      <div className="bg-slate-900 border-t border-slate-800 px-3 py-1.5 flex items-center justify-between text-[11px] text-slate-400 font-mono select-none">
        <div className="flex items-center gap-3">
          <span>Righe: {lines.length}</span>
          <span>Caratteri: {file.content.length}</span>
          <span>UTF-8</span>
          <span className="text-emerald-400 font-sans">Luau v0.6+</span>
        </div>

        <div className="flex items-center gap-3">
          {errorCount === 0 && warningCount === 0 ? (
            <span className="flex items-center gap-1 text-emerald-400">
              <Check className="w-3 h-3" />
              Sintassi Luau Valida
            </span>
          ) : (
            <div className="flex items-center gap-2">
              {errorCount > 0 && (
                <span className="flex items-center gap-1 text-rose-400 font-medium">
                  <AlertCircle className="w-3 h-3" />
                  {errorCount} {errorCount === 1 ? "errore" : "errori"}
                </span>
              )}
              {warningCount > 0 && (
                <span className="flex items-center gap-1 text-amber-400">
                  <AlertTriangle className="w-3 h-3" />
                  {warningCount} {warningCount === 1 ? "avviso" : "avvisi"}
                </span>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

import React, { useState } from "react";
import { 
  AlertCircle, 
  AlertTriangle, 
  CheckCircle2, 
  Wand2, 
  ArrowRight, 
  Check, 
  Sparkles, 
  Loader2,
  Bug
} from "lucide-react";
import { ProjectFile, SyntaxIssue } from "../types";

interface RealtimeDebuggerProps {
  activeFile: ProjectFile;
  syntaxIssues: SyntaxIssue[];
  onApplyFixedCode: (fixedCode: string) => void;
}

export const RealtimeDebugger: React.FC<RealtimeDebuggerProps> = ({
  activeFile,
  syntaxIssues,
  onApplyFixedCode,
}) => {
  const [isDebugging, setIsDebugging] = useState(false);
  const [debugResult, setDebugResult] = useState<{
    isValid: boolean;
    summary: string;
    issues: { line: number; severity: string; message: string; suggestion: string }[];
    fixedCode: string;
    explanation: string;
  } | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [applied, setApplied] = useState(false);

  const errors = syntaxIssues.filter((i) => i.severity === "error");
  const warnings = syntaxIssues.filter((i) => i.severity === "warning");

  const handleRunAiDebug = async () => {
    setIsDebugging(true);
    setErrorMsg(null);
    setApplied(false);

    try {
      const res = await fetch("/api/gemini/debug-lua", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code: activeFile.content,
          detectedErrors: syntaxIssues,
          context: `${activeFile.type} in ${activeFile.parentPath}`,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || "Errore durante il debugging.");
      }

      setDebugResult(data);
    } catch (err: any) {
      setErrorMsg(err.message || "Impossibile completare il debug.");
    } finally {
      setIsDebugging(false);
    }
  };

  const handleApply = () => {
    if (debugResult?.fixedCode) {
      onApplyFixedCode(debugResult.fixedCode);
      setApplied(true);
      setTimeout(() => setApplied(false), 2500);
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-3">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <Bug className="w-4 h-4 text-red-500" />
          <span className="font-semibold text-xs text-slate-200">
            Debugger Luau in Tempo Reale
          </span>
          <span className="text-[10px] text-slate-400 font-mono">
            ({activeFile.name}.luau)
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRunAiDebug}
            disabled={isDebugging}
            className="flex items-center gap-1.5 px-3 py-1 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 disabled:opacity-50 text-white font-medium text-xs rounded shadow transition-all active:scale-95"
          >
            {isDebugging ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Analisi Gemini 3.8...</span>
              </>
            ) : (
              <>
                <Wand2 className="w-3.5 h-3.5" />
                <span>Risolvi Errori con AI</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Local Realtime Linter Issues */}
      {syntaxIssues.length === 0 ? (
        <div className="flex items-center gap-2 p-2 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs">
          <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
          <span>Nessun errore di sintassi rilevato nel codice Luau. Il codice è pronto per l'esecuzione!</span>
        </div>
      ) : (
        <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
          {syntaxIssues.map((issue, idx) => (
            <div
              key={idx}
              className={`flex items-start justify-between p-2 rounded border text-xs gap-2 ${
                issue.severity === "error"
                  ? "bg-rose-500/10 border-rose-500/30 text-rose-300"
                  : "bg-amber-500/10 border-amber-500/30 text-amber-300"
              }`}
            >
              <div className="flex items-start gap-2 min-w-0">
                {issue.severity === "error" ? (
                  <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-rose-400" />
                ) : (
                  <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5 text-amber-400" />
                )}
                <div>
                  <div className="font-semibold text-[11px]">
                    Riga {issue.line}: {issue.message}
                  </div>
                  {issue.suggestion && (
                    <div className="text-[10px] opacity-80 mt-0.5">
                      Suggerimento: {issue.suggestion}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {errorMsg && (
        <div className="p-2 rounded bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          {errorMsg}
        </div>
      )}

      {/* AI Debug Diagnosis & Auto-Fix Card */}
      {debugResult && (
        <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Soluzione Ottimale Trovata da Gemini 3.8</span>
            </div>

            <button
              onClick={handleApply}
              className="flex items-center gap-1 px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded shadow transition-colors"
            >
              {applied ? <Check className="w-3 h-3" /> : <ArrowRight className="w-3 h-3" />}
              <span>{applied ? "Correzione Applicata!" : "Applica al File"}</span>
            </button>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/80 p-2.5 rounded border border-slate-800">
            {debugResult.explanation}
          </p>

          <div className="text-[11px] text-slate-400">
            Anteprima codice corretto:
          </div>
          <pre className="p-2.5 rounded bg-slate-900 border border-slate-800 font-mono text-[11px] text-slate-200 max-h-36 overflow-auto whitespace-pre">
            {debugResult.fixedCode}
          </pre>
        </div>
      )}
    </div>
  );
};

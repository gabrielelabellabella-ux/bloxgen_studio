import React, { useState } from "react";
import { 
  X, 
  Download, 
  FolderOpen, 
  Check, 
  Copy, 
  Sparkles, 
  ExternalLink, 
  Radio, 
  ShieldCheck, 
  Laptop, 
  Apple, 
  Monitor, 
  HelpCircle, 
  ChevronRight,
  Terminal,
  FileCode,
  Zap,
  CheckCircle2,
  AlertTriangle
} from "lucide-react";
import confetti from "canvas-confetti";
import { sfx } from "../utils/soundEffects";

interface PluginInstallTutorialModalProps {
  isOpen: boolean;
  onClose: () => void;
  isStudioConnected?: boolean;
}

export const PluginInstallTutorialModal: React.FC<PluginInstallTutorialModalProps> = ({
  isOpen,
  onClose,
  isStudioConnected = false,
}) => {
  const [selectedOs, setSelectedOs] = useState<"windows" | "mac">("windows");
  const [selectedMethod, setSelectedMethod] = useState<"folder" | "studio">("folder");
  const [copiedPath, setCopiedPath] = useState<boolean>(false);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [isTestingPing, setIsTestingPing] = useState<boolean>(false);
  const [pingResult, setPingResult] = useState<string | null>(null);

  if (!isOpen) return null;

  const windowsPath = "%localappdata%\\Roblox\\Plugins";
  const macPath = "~/Library/Application Support/Roblox/Plugins";

  const handleCopyPath = () => {
    sfx.playPop();
    const path = selectedOs === "windows" ? windowsPath : macPath;
    navigator.clipboard.writeText(path);
    setCopiedPath(true);
    setTimeout(() => setCopiedPath(false), 2500);
  };

  const handleDownloadPlugin = () => {
    sfx.playSuccess();
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
        colors: ["#ef4444", "#10b981", "#3b82f6", "#f59e0b"],
      });
    } catch (e) {
      // ignore
    }
  };

  const handleCopyPluginCode = async () => {
    sfx.playPop();
    try {
      const originParam = typeof window !== "undefined" ? `?origin=${encodeURIComponent(window.location.origin)}` : "";
      const res = await fetch(`/api/sync/plugin.lua${originParam}`);
      if (res.ok) {
        const text = await res.text();
        navigator.clipboard.writeText(text);
        setCopiedCode(true);
        setTimeout(() => setCopiedCode(false), 2500);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleTestConnection = async () => {
    sfx.playLaser();
    setIsTestingPing(true);
    setPingResult(null);
    try {
      const res = await fetch("/api/sync/status");
      const data = await res.json();
      if (data.connected) {
        sfx.playSuccess();
        setPingResult(`✅ Roblox Studio CONNESSO a "${data.session.placeName}" (PlaceId: ${data.session.placeId})`);
      } else {
        sfx.playWarn();
        setPingResult("⚠️ Nessuna sessione di Roblox Studio attiva rilevata. Apri Studio e assicurati che 'Allow HTTP Requests' sia abilitato.");
      }
    } catch (err: any) {
      sfx.playWarn();
      setPingResult("❌ Errore durante il test di connessione: " + err.message);
    } finally {
      setIsTestingPing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-3xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl shadow-red-950/20 flex flex-col max-h-[90vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Glowing top accent line */}
        <div className="h-1 w-full bg-gradient-to-r from-red-500 via-amber-500 to-emerald-500" />

        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400 shadow-inner">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-100 tracking-tight">
                  Guida: Come Installare il Plugin in Modo Permanente
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  Consigliato
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Installalo una volta sola: si avvierà automaticamente a ogni apertura di Roblox Studio in qualsiasi progetto.
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sfx.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-slate-100 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-slate-300 text-sm">
          {/* Method Selector Tabs */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-950/80 p-1.5 rounded-xl border border-slate-800">
            <div className="flex items-center gap-1">
              <button
                onClick={() => {
                  sfx.playClick();
                  setSelectedMethod("folder");
                }}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  selectedMethod === "folder"
                    ? "bg-red-600 text-white shadow-md shadow-red-600/20"
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
                }`}
              >
                <FileCode className="w-3.5 h-3.5" />
                <span>File .lua (Cartella Plugins o Cartella Roblox)</span>
              </button>

              <button
                onClick={() => {
                  sfx.playClick();
                  setSelectedMethod("studio");
                }}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  selectedMethod === "studio"
                    ? "bg-red-600 text-white shadow-md shadow-red-600/20"
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
                }`}
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copia Codice .lua Diretto</span>
              </button>
            </div>

            {/* OS Selector (Windows vs macOS) */}
            <div className="flex items-center gap-1 bg-slate-900 px-1 py-1 rounded-lg border border-slate-800">
              <button
                onClick={() => {
                  sfx.playClick();
                  setSelectedOs("windows");
                }}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                  selectedOs === "windows"
                    ? "bg-slate-800 text-white shadow-sm"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                <Monitor className="w-3.5 h-3.5 text-blue-400" />
                <span>Windows</span>
              </button>

              <button
                onClick={() => {
                  sfx.playClick();
                  setSelectedOs("mac");
                }}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                  selectedOs === "mac"
                    ? "bg-slate-800 text-white shadow-sm"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                <Apple className="w-3.5 h-3.5 text-slate-300" />
                <span>macOS</span>
              </button>
            </div>
          </div>

          {/* METHOD 1: Direct .lua File */}
          {selectedMethod === "folder" && (
            <div className="space-y-4">
              {/* How it works highlight */}
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-red-950/40 via-slate-900 to-slate-900 border border-red-500/30 text-xs space-y-1.5 shadow-sm">
                <div className="flex items-center gap-2 text-red-400 font-bold">
                  <Sparkles className="w-4 h-4" />
                  <span>Nuovo Plugin .lua Interattivo con Schermata di Connessione</span>
                </div>
                <p className="text-slate-300 leading-relaxed">
                  Il file <strong className="text-white">.lua</strong> crea automaticamente il pulsante nella scheda <strong className="text-emerald-400">PLUGINS</strong> di Roblox Studio. 
                  Cliccandoci si aprirà una schermata con il pulsante <strong className="text-rose-400 font-semibold">"Connetti a BloxGen Studio"</strong>: basta un click per collegarsi al sito e far partire tutte le modifiche in tempo reale!
                </p>
              </div>

              {/* Step 1: Download or Copy Lua File */}
              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800/90 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-red-600 text-white font-bold text-xs flex items-center justify-center">
                      1
                    </span>
                    <span className="font-semibold text-slate-200 text-sm">
                      Scarica il file .lua del Plugin
                    </span>
                  </div>
                  <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    File: BloxGenStudioLiveSync.lua
                  </span>
                </div>

                <p className="text-xs text-slate-400 pl-8">
                  Scarica il file Luau pronto con l'interfaccia Studio integrata, oppure copialo negli appunti:
                </p>

                <div className="pl-8 pt-1 flex flex-wrap items-center gap-3">
                  <a
                    href={`/api/sync/plugin.lua?origin=${encodeURIComponent(typeof window !== "undefined" ? window.location.origin : "")}`}
                    download="BloxGenStudioLiveSync.lua"
                    onClick={handleDownloadPlugin}
                    className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-red-600/25 transition-all transform active:scale-95 group"
                  >
                    <Download className="w-4 h-4 group-hover:-translate-y-0.5 transition-transform" />
                    <span>Scarica BloxGenStudioLiveSync.lua</span>
                  </a>

                  <button
                    onClick={handleCopyPluginCode}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition-colors shadow-sm"
                  >
                    {copiedCode ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    <span>{copiedCode ? "Codice .lua Copiato!" : "Copia Codice .lua"}</span>
                  </button>

                  <a
                    href={`/api/sync/plugin.rbxmx?origin=${encodeURIComponent(typeof window !== "undefined" ? window.location.origin : "")}`}
                    download="BloxGenStudioLiveSync.rbxmx"
                    onClick={handleDownloadPlugin}
                    className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-300 text-xs font-medium rounded-xl border border-slate-800 transition-colors"
                    title="Formato opzionale modello XML Roblox"
                  >
                    <FileCode className="w-3.5 h-3.5 text-slate-500" />
                    <span>Disponibile anche in .rbxmx</span>
                  </a>
                </div>
              </div>

              {/* Step 2: Where to put it */}
              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800/90 space-y-3">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-red-600 text-white font-bold text-xs flex items-center justify-center">
                    2
                  </span>
                  <span className="font-semibold text-slate-200 text-sm">
                    Inserisci il file nella cartella Plugins (oppure dentro una cartella in Roblox)
                  </span>
                </div>

                <p className="text-xs text-slate-400 pl-8">
                  Hai due modalità semplicissime:
                </p>

                <div className="pl-8 space-y-2.5">
                  <div className="p-3 bg-slate-900/90 rounded-lg border border-slate-800 text-xs">
                    <strong className="text-slate-200">Opzione A (Cartella Plugins di Roblox Studio - Permanente):</strong>
                    <p className="text-slate-400 mt-1">
                      In Studio, vai nella scheda <span className="text-emerald-400 font-medium">PLUGINS</span> &gt; clicca su <span className="text-emerald-400 font-medium">"Plugins Folder"</span> e incolla il file <code className="text-emerald-300 font-mono">BloxGenStudioLiveSync.lua</code>.
                    </p>
                    <div className="mt-2 flex items-center justify-between">
                      <span className="text-[11px] text-slate-400">Percorso cartella locale ({selectedOs}):</span>
                      <button
                        onClick={handleCopyPath}
                        className="flex items-center gap-1 text-[11px] px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
                      >
                        {copiedPath ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedPath ? "Copiato!" : "Copia Percorso"}</span>
                      </button>
                    </div>
                    <code className="block mt-1 p-1.5 bg-slate-950 rounded text-emerald-400 font-mono text-[11px] select-all">
                      {selectedOs === "windows" ? windowsPath : macPath}
                    </code>
                  </div>

                  <div className="p-3 bg-slate-900/90 rounded-lg border border-slate-800 text-xs">
                    <strong className="text-slate-200">Opzione B (Direttamente in una cartella in Roblox Explorer):</strong>
                    <p className="text-slate-400 mt-1">
                      Crea una nuova <strong className="text-slate-200">Folder</strong> o vai in <strong className="text-slate-200">ServerScriptService</strong> in Explorer, aggiungi uno <strong className="text-slate-200">Script</strong>, incolla il codice .lua e avvia: l'interfaccia di connessione comparirà direttamente a schermo!
                    </p>
                  </div>
                </div>
              </div>

              {/* Step 3: Click button and connect */}
              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800/90 space-y-3">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center">
                    3
                  </span>
                  <span className="font-semibold text-slate-200 text-sm">
                    Clicca sul pulsante nella scheda PLUGINS e premi "Connetti a BloxGen Studio"
                  </span>
                </div>

                <div className="pl-8 space-y-2 text-xs text-slate-300">
                  <p>
                    1. In Roblox Studio, clicca sul pulsante visibile <strong className="text-emerald-400">"BloxGen Connect"</strong> nella scheda PLUGINS.
                  </p>
                  <p>
                    2. Si aprirà la schermata interattiva con il nome del sito e il pulsante <strong className="text-rose-400 font-bold">"⚡ Connetti a BloxGen Studio"</strong>.
                  </p>
                  <p>
                    3. Clicca su <strong className="text-rose-400 font-bold">"Connetti a BloxGen Studio"</strong>: lo stato diventerà verde (<strong className="text-emerald-400 font-semibold">🟢 Connesso</strong>) e <strong className="text-white">partono subito tutte le modifiche</strong> al tuo gioco generate dall'AI!
                  </p>
                </div>

                {/* Simulated Studio Window Mockup */}
                <div className="mt-3 pl-8">
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-700/80 max-w-md shadow-xl text-xs space-y-2">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                      <span className="font-bold text-white flex items-center gap-1.5">
                        <Zap className="w-3.5 h-3.5 text-rose-500" />
                        Finestra Studio: BloxGen - Connetti
                      </span>
                      <span className="text-[10px] text-emerald-400 font-mono">DockWidget</span>
                    </div>

                    <div className="p-2 bg-slate-950 rounded-lg border border-slate-800">
                      <div className="text-[10px] text-slate-400">Sito Web Collegato:</div>
                      <div className="text-[11px] font-mono text-emerald-400 font-semibold truncate">
                        BloxGen Studio Live Bridge
                      </div>
                    </div>

                    <div className="p-2 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-emerald-300 font-semibold flex items-center gap-1.5 text-[11px]">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>🟢 Connesso a BloxGen Studio! Modifiche attive</span>
                    </div>

                    <div className="w-full py-2 bg-rose-600 text-white rounded-lg font-bold text-center text-xs shadow-md">
                      ⚡ Connetti a BloxGen Studio
                    </div>

                    <div className="p-2 bg-black/40 rounded border border-slate-800 font-mono text-[10px] text-slate-400 space-y-0.5">
                      <div className="text-emerald-400">✅ Connesso a BloxGen Studio!</div>
                      <div className="text-slate-300">🚀 Partono le modifiche in tempo reale dall'AI...</div>
                      <div className="text-slate-400">✨ [Sync] In ascolto modifiche progetti e script</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* METHOD 2: Copy .lua Code directly */}
          {selectedMethod === "studio" && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800/90 space-y-3">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-red-600 text-white font-bold text-xs flex items-center justify-center">
                    1
                  </span>
                  <span className="font-semibold text-slate-200 text-sm">
                    Copia il Codice Luau Completo (.lua)
                  </span>
                </div>
                <p className="text-xs text-slate-400 pl-8">
                  Premi il pulsante sottostante per copiare il codice Luau del plugin con la GUI di connessione e il bridge integrato.
                </p>
                <div className="pl-8">
                  <button
                    onClick={handleCopyPluginCode}
                    className="flex items-center gap-2 px-4 py-2.5 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-red-600/20"
                  >
                    {copiedCode ? <Check className="w-4 h-4 text-white" /> : <Copy className="w-4 h-4" />}
                    <span>{copiedCode ? "Codice Luau Copiato negli Appunti!" : "Copia Codice .lua del Plugin"}</span>
                  </button>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800/90 space-y-2">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-red-600 text-white font-bold text-xs flex items-center justify-center">
                    2
                  </span>
                  <span className="font-semibold text-slate-200 text-sm">
                    Incolla in un nuovo Script in una cartella di Roblox
                  </span>
                </div>
                <p className="text-xs text-slate-400 pl-8">
                  In Roblox Studio, apri l'Explorer, crea una cartella o vai in <strong className="text-slate-200">ServerScriptService</strong> e inserisci uno <strong className="text-slate-200">Script</strong>. Incolla il codice appena copiato.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800/90 space-y-2">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center">
                    3
                  </span>
                  <span className="font-semibold text-slate-200 text-sm">
                    (Opzionale) Salva come Plugin Locale: Click Destro &gt; "Save as Local Plugin..."
                  </span>
                </div>
                <p className="text-xs text-slate-400 pl-8">
                  Fai click destro sullo script in Explorer e seleziona <strong className="text-emerald-400">"Save as Local Plugin..."</strong>. In questo modo comparirà per sempre nella barra <strong className="text-white">PLUGINS</strong> con il suo pulsante dedicato!
                </p>
              </div>
            </div>
          )}

          {/* CRITICAL PREREQUISITE: Allow HTTP Requests & Troubleshooting */}
          <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs space-y-2.5">
            <div className="flex items-center gap-2 font-bold text-amber-300">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <span>Requisito Fondamentale in Roblox Studio (Security & HTTP)</span>
            </div>
            <p className="text-slate-300 leading-relaxed">
              Roblox per motivi di sicurezza blocca qualsiasi comunicazione verso l'esterno finché non la autorizzi per la tua esperienza:
            </p>
            <ol className="list-decimal list-inside space-y-1.5 text-slate-300 pl-1 font-medium">
              <li>
                In Roblox Studio, apri la scheda <strong className="text-white">Home &gt; Game Settings</strong> nella barra superiore.
              </li>
              <li>
                Se il menu è grigio o chiede la pubblicazione: fai prima <strong className="text-amber-300">File &gt; Publish to Roblox</strong> (altrimenti Studio non può salvare le opzioni di sicurezza).
              </li>
              <li>
                Entra nella sezione <strong className="text-white">Security</strong>.
              </li>
              <li>
                Attiva l'interruttore <strong className="text-emerald-300">"Allow HTTP Requests"</strong> (impostalo su <strong>ON</strong>).
              </li>
              <li>
                ⚠️ <strong className="text-amber-300">FONDAMENTALE:</strong> Clicca sul tasto verde <strong className="text-white">"Save"</strong> in basso a destra nella finestra di dialogo!
              </li>
            </ol>
            <div className="mt-2 p-2.5 bg-slate-900/90 rounded-lg border border-amber-500/20 text-[11px] text-slate-300 space-y-1">
              <div className="font-semibold text-amber-300 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                <span>Cosa fare se Studio continua a dire di abilitare le HTTP Requests anche se già attive?</span>
              </div>
              <p className="text-slate-400">
                1. <strong>Verifica l'indirizzo del server:</strong> Nella finestra del plugin troverai la casella <em>"Indirizzo Server Web BloxGen Studio"</em>. Assicurati che contenga l'URL pubblico HTTPS di questa pagina (non localhost o un indirizzo errato). Puoi modificarlo e incollare l'URL direttamente lì dentro!
              </p>
              <p className="text-slate-400">
                2. <strong>Diagnostica dettagliata:</strong> Il nuovo plugin non dà più falsi allarmi: nella console in basso ti stamperà esattamente l'errore di rete (connessione fallita, DNS o certificato), così saprai subito come procedere.
              </p>
            </div>
          </div>

          {/* Real-time Connection Checker Box */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div
                className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                  isStudioConnected
                    ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                    : "bg-slate-800 text-slate-400"
                }`}
              >
                <Radio className={`w-4 h-4 ${isStudioConnected ? "animate-pulse" : ""}`} />
              </div>
              <div>
                <div className="text-xs font-semibold text-slate-200">
                  Stato Attuale del Bridge:{" "}
                  {isStudioConnected ? (
                    <span className="text-emerald-400 font-bold">CONNESSO</span>
                  ) : (
                    <span className="text-rose-400 font-bold">NON CONNESSO</span>
                  )}
                </div>
                <p className="text-[11px] text-slate-400">
                  {isStudioConnected
                    ? "Il plugin è attivo e dialoga in tempo reale con questa finestra!"
                    : "Installa il plugin o esegui il comando per stabilire il collegamento."}
                </p>
              </div>
            </div>

            <button
              onClick={handleTestConnection}
              disabled={isTestingPing}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 transition-all flex items-center gap-1.5"
            >
              <Zap className={`w-3.5 h-3.5 text-amber-400 ${isTestingPing ? "animate-spin" : ""}`} />
              <span>Verifica Connessione</span>
            </button>
          </div>

          {pingResult && (
            <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300 animate-in fade-in">
              {pingResult}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-900/90 flex items-center justify-between">
          <span className="text-xs text-slate-400 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-red-500" />
            Compatibile con qualsiasi versione di Roblox Studio (Windows & Mac)
          </span>

          <button
            onClick={() => {
              sfx.playClick();
              onClose();
            }}
            className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-white text-xs font-bold rounded-lg shadow transition-colors"
          >
            Ho Capito, Chiudi
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from "react";
import { 
  Gauge, 
  Zap, 
  Check, 
  ArrowUpRight, 
  Cpu, 
  Database, 
  Wifi, 
  Sparkles, 
  Loader2, 
  FileCheck 
} from "lucide-react";
import { ProjectFile } from "../types";

interface PerformanceOptimizerProps {
  activeFile: ProjectFile;
  onApplyOptimizedCode: (code: string) => void;
}

export const PerformanceOptimizer: React.FC<PerformanceOptimizerProps> = ({
  activeFile,
  onApplyOptimizedCode,
}) => {
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [targetFPS, setTargetFPS] = useState<number>(60);
  const [applied, setApplied] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [result, setResult] = useState<{
    performanceScoreBefore: number;
    performanceScoreAfter: number;
    optimizations: { category: string; title: string; description: string }[];
    optimizedCode: string;
    summary: string;
  } | null>(null);

  const handleRunOptimizer = async () => {
    setIsOptimizing(true);
    setErrorMsg(null);
    setApplied(false);

    try {
      const res = await fetch("/api/gemini/optimize-lua", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code: activeFile.content,
          targetFPS,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || "Ottimizzazione fallita");
      }

      setResult(data);
    } catch (err: any) {
      setErrorMsg(err.message || "Errore durante l'ottimizzazione del codice");
    } finally {
      setIsOptimizing(false);
    }
  };

  const handleApply = () => {
    if (result?.optimizedCode) {
      onApplyOptimizedCode(result.optimizedCode);
      setApplied(true);
      setTimeout(() => setApplied(false), 2500);
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 p-4 space-y-4 overflow-y-auto">
      {/* Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Gauge className="w-5 h-5 text-amber-500" />
            <h2 className="text-base font-semibold text-slate-100">
              Roblox Luau Performance Profiler & Optimizer
            </h2>
            <span className="text-[10px] bg-amber-500/10 text-amber-400 font-mono px-2 py-0.5 rounded border border-amber-500/20">
              Garbage Collector & 60-120 FPS Engine
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Analizza l'efficienza del codice Luau per prevenire cali di frame rate (FPS drop), bloccare memory leak
            causati da eventi non disconnessi, pre-allocare array con <code className="text-amber-400">table.create()</code>,
            e sfruttare la compilazione nativa con <code className="text-amber-400">--!native</code>.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 bg-slate-950 px-2.5 py-1 rounded border border-slate-800 text-xs">
            <span className="text-slate-400">Target:</span>
            {[60, 120, 144].map((fps) => (
              <button
                key={fps}
                onClick={() => setTargetFPS(fps)}
                className={`px-2 py-0.5 rounded text-[11px] font-mono transition-colors ${
                  targetFPS === fps
                    ? "bg-amber-500 text-slate-950 font-bold"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                {fps} FPS
              </button>
            ))}
          </div>

          <button
            onClick={handleRunOptimizer}
            disabled={isOptimizing}
            className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 disabled:opacity-50 text-slate-950 font-bold text-xs rounded-md shadow transition-all active:scale-95"
          >
            {isOptimizing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Analisi Profiler...</span>
              </>
            ) : (
              <>
                <Zap className="w-4 h-4" />
                <span>Profila & Ottimizza Ora</span>
              </>
            )}
          </button>
        </div>
      </div>

      {errorMsg && (
        <div className="p-3 rounded bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          {errorMsg}
        </div>
      )}

      {/* Main Content Area */}
      {result ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Metrics & Optimizations list */}
          <div className="lg:col-span-5 space-y-4">
            {/* Score Comparison Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex items-center justify-around">
              <div className="text-center">
                <span className="text-[11px] text-slate-400 block mb-1">Score Iniziale</span>
                <span className="text-3xl font-black text-rose-400 font-mono">
                  {result.performanceScoreBefore}
                </span>
                <span className="text-[10px] text-slate-500 block">/ 100</span>
              </div>

              <div className="flex flex-col items-center">
                <ArrowUpRight className="w-6 h-6 text-emerald-400 animate-pulse" />
                <span className="text-xs font-bold text-emerald-400 font-mono mt-1">
                  +{result.performanceScoreAfter - result.performanceScoreBefore}%
                </span>
              </div>

              <div className="text-center">
                <span className="text-[11px] text-slate-400 block mb-1">Score Ottimizzato</span>
                <span className="text-3xl font-black text-emerald-400 font-mono">
                  {result.performanceScoreAfter}
                </span>
                <span className="text-[10px] text-slate-500 block">/ 100</span>
              </div>
            </div>

            {/* Summary */}
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-1 text-xs">
              <span className="font-semibold text-slate-200">Sintesi Miglioramenti:</span>
              <p className="text-slate-300 leading-relaxed">{result.summary}</p>
            </div>

            {/* Specific Optimizations list */}
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-2">
              <span className="font-semibold text-xs text-slate-200 block">
                Ottimizzazioni Applicate ({result.optimizations?.length || 0}):
              </span>

              <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
                {result.optimizations?.map((opt, i) => {
                  const Icon =
                    opt.category === "Memory"
                      ? Database
                      : opt.category === "Network"
                      ? Wifi
                      : Cpu;

                  return (
                    <div
                      key={i}
                      className="p-2.5 rounded bg-slate-950 border border-slate-800/80 text-xs space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5 font-semibold text-slate-200">
                          <Icon className="w-3.5 h-3.5 text-amber-400" />
                          <span>{opt.title}</span>
                        </div>
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
                          {opt.category}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        {opt.description}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Optimized Code Preview */}
          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <FileCheck className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-semibold text-slate-200">
                  Codice Luau Ottimizzato ({activeFile.name}.luau)
                </span>
              </div>

              <button
                onClick={handleApply}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded shadow transition-all active:scale-95"
              >
                {applied ? <Check className="w-3.5 h-3.5" /> : <Sparkles className="w-3.5 h-3.5" />}
                <span>{applied ? "Applicato allo Script!" : "Applica Modifiche"}</span>
              </button>
            </div>

            <pre className="flex-1 bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono text-xs text-slate-300 overflow-auto whitespace-pre min-h-[380px]">
              {result.optimizedCode}
            </pre>
          </div>
        </div>
      ) : (
        <div className="flex-1 bg-slate-900 border border-slate-800 rounded-lg p-8 flex flex-col items-center justify-center text-center space-y-3">
          <div className="w-14 h-14 rounded-full bg-slate-950 border border-slate-800 flex items-center justify-center text-amber-400">
            <Gauge className="w-7 h-7" />
          </div>
          <h3 className="text-sm font-semibold text-slate-200">
            Script Attuale: {activeFile.name}.luau ({activeFile.content.split("\n").length} righe)
          </h3>
          <p className="text-xs text-slate-400 max-w-md">
            Fai clic su <strong className="text-amber-400">"Profila & Ottimizza Ora"</strong> in alto a destra per avviare
            l'ispezione Luau con Gemini 3.8 e ottenere suggerimenti istantanei di micro-ottimizzazione.
          </p>
        </div>
      )}
    </div>
  );
};

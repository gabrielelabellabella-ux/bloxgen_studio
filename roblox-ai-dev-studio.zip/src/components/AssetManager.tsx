import React, { useState, useRef } from "react";
import { 
  Upload, 
  Image as ImageIcon, 
  Copy, 
  Check, 
  Sparkles, 
  FileCode, 
  Trash2, 
  Plus,
  Box,
  Layers,
  Palette
} from "lucide-react";
import { GraphicAsset } from "../types";

interface AssetManagerProps {
  onInjectAssetToPrompt: (asset: GraphicAsset) => void;
  onInsertCodeToActiveFile: (code: string) => void;
}

const PRESET_SAMPLE_ASSETS: GraphicAsset[] = [
  {
    id: "asset-crosshair",
    name: "TacticalCrosshair",
    assetType: "ImageLabel",
    mimeType: "image/svg+xml",
    sizeBytes: 4200,
    rbxIdPlaceholder: "rbxassetid://9123847120",
    dataUrl: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='128' height='128' viewBox='0 0 128 128'><circle cx='64' cy='64' r='48' fill='none' stroke='%2338bdf8' stroke-width='4'/><circle cx='64' cy='64' r='8' fill='%23ef4444'/><line x1='64' y1='8' x2='64' y2='36' stroke='%2338bdf8' stroke-width='4'/><line x1='64' y1='92' x2='64' y2='120' stroke='%2338bdf8' stroke-width='4'/><line x1='8' y1='64' x2='36' y2='64' stroke='%2338bdf8' stroke-width='4'/><line x1='92' y1='64' x2='120' y2='64' stroke='%2338bdf8' stroke-width='4'/></svg>",
  },
  {
    id: "asset-potion",
    name: "HealthShieldPotion",
    assetType: "ImageButton",
    mimeType: "image/svg+xml",
    sizeBytes: 5100,
    rbxIdPlaceholder: "rbxassetid://8742918471",
    dataUrl: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='128' height='128' viewBox='0 0 128 128'><path d='M44 24 h40 v16 h-40 z' fill='%2394a3b8'/><path d='M36 40 c0 0 -16 28 -16 52 a44 44 0 0 0 88 0 c0 -24 -16 -52 -16 -52 z' fill='%233b82f6' fill-opacity='0.85'/><circle cx='54' cy='74' r='6' fill='%23ffffff' fill-opacity='0.6'/><circle cx='70' cy='86' r='4' fill='%23ffffff' fill-opacity='0.6'/></svg>",
  },
  {
    id: "asset-hex-tile",
    name: "SciFiHexFloor",
    assetType: "Texture",
    mimeType: "image/svg+xml",
    sizeBytes: 6300,
    rbxIdPlaceholder: "rbxassetid://7412093842",
    dataUrl: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='128' height='128' viewBox='0 0 128 128'><polygon points='64,8 120,40 120,88 64,120 8,88 8,40' fill='none' stroke='%23f59e0b' stroke-width='4'/><circle cx='64' cy='64' r='20' fill='%23f59e0b' fill-opacity='0.3'/></svg>",
  },
];

export const AssetManager: React.FC<AssetManagerProps> = ({
  onInjectAssetToPrompt,
  onInsertCodeToActiveFile,
}) => {
  const [assets, setAssets] = useState<GraphicAsset[]>(PRESET_SAMPLE_ASSETS);
  const [selectedAsset, setSelectedAsset] = useState<GraphicAsset>(PRESET_SAMPLE_ASSETS[0]);
  const [copiedSnippet, setCopiedSnippet] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          const newAsset: GraphicAsset = {
            id: `asset-${Date.now()}-${i}`,
            name: file.name.replace(/\.[^/.]+$/, "").replace(/[^a-zA-Z0-9_]/g, ""),
            mimeType: file.type || "image/png",
            sizeBytes: file.size,
            dataUrl: event.target!.result as string,
            assetType: file.name.toLowerCase().includes("btn") ? "ImageButton" : "ImageLabel",
            rbxIdPlaceholder: `rbxassetid://${Math.floor(1000000000 + Math.random() * 9000000000)}`,
          };
          setAssets((prev) => [newAsset, ...prev]);
          setSelectedAsset(newAsset);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDeleteAsset = (id: string) => {
    const updated = assets.filter((a) => a.id !== id);
    setAssets(updated);
    if (selectedAsset.id === id && updated.length > 0) {
      setSelectedAsset(updated[0]);
    }
  };

  // Generate Luau Code for the selected asset
  const getLuauSnippet = (asset: GraphicAsset): string => {
    if (asset.assetType === "ImageLabel") {
      return `-- Inserimento Responsive ImageLabel
local imageLabel = Instance.new("ImageLabel")
imageLabel.Name = "${asset.name}"
imageLabel.Image = "${asset.rbxIdPlaceholder}" -- Asset ID Roblox
imageLabel.BackgroundTransparency = 1
imageLabel.Position = UDim2.fromScale(0.5, 0.5)
imageLabel.Size = UDim2.fromScale(0.2, 0.2)
imageLabel.AnchorPoint = Vector2.new(0.5, 0.5)
imageLabel.ScaleType = Enum.ScaleType.Fit

-- Vincolo proporzioni per evitare allungamenti
local aspect = Instance.new("UIAspectRatioConstraint")
aspect.AspectRatio = 1.0
aspect.Parent = imageLabel
imageLabel.Parent = script.Parent
`;
    }

    if (asset.assetType === "ImageButton") {
      return `-- Inserimento ImageButton con Hover Animation
local button = Instance.new("ImageButton")
button.Name = "${asset.name}"
button.Image = "${asset.rbxIdPlaceholder}"
button.BackgroundTransparency = 1
button.Position = UDim2.fromScale(0.5, 0.5)
button.Size = UDim2.fromScale(0.15, 0.15)
button.AnchorPoint = Vector2.new(0.5, 0.5)

button.MouseEnter:Connect(function()
	button:TweenSize(UDim2.fromScale(0.17, 0.17), Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 0.15, true)
end)

button.MouseLeave:Connect(function()
	button:TweenSize(UDim2.fromScale(0.15, 0.15), Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 0.15, true)
end)

button.Activated:Connect(function()
	print("[UI] Cliccato pulsante: ${asset.name}")
end)

button.Parent = script.Parent
`;
    }

    if (asset.assetType === "Decal") {
      return `-- Decal su BasePart in Workspace
local part = workspace:WaitForChild("Part")
local decal = Instance.new("Decal")
decal.Name = "${asset.name}_Decal"
decal.Texture = "${asset.rbxIdPlaceholder}"
decal.Face = Enum.NormalId.Top
decal.Parent = part
`;
    }

    return `-- Texture scalabile ripetuta (Tiling)
local part = workspace:WaitForChild("Floor")
local texture = Instance.new("Texture")
texture.Name = "${asset.name}_Texture"
texture.Texture = "${asset.rbxIdPlaceholder}"
texture.Face = Enum.NormalId.Top
texture.StudsPerTileU = 4
texture.StudsPerTileV = 4
texture.Parent = part
`;
  };

  const currentSnippet = getLuauSnippet(selectedAsset);

  const handleCopySnippet = () => {
    navigator.clipboard.writeText(currentSnippet);
    setCopiedSnippet(true);
    setTimeout(() => setCopiedSnippet(false), 2000);
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 p-4 space-y-4 overflow-y-auto">
      {/* Title & Description */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ImageIcon className="w-5 h-5 text-red-500" />
            <h2 className="text-base font-semibold text-slate-100">
              Roblox Asset Manager & Graphic Bridge
            </h2>
            <span className="text-[10px] bg-red-500/10 text-red-400 font-mono px-2 py-0.5 rounded border border-red-500/20">
              Texture / Decal / ImageLabel
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Carica texture, icone GUI, decalcomanie o mappe normali: genera istantaneamente il codice Luau
            corretto con formattazione <code className="text-red-400">UDim2.fromScale()</code> e vincoli di aspect ratio,
            oppure includile direttamente nel prompt di Gemini 3.8 per integrarle nel codice generato.
          </p>
        </div>

        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileUpload}
          accept="image/*"
          multiple
          className="hidden"
        />
        <button
          onClick={() => fileInputRef.current?.click()}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white text-xs font-semibold rounded-md shadow transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Carica Nuovi Asset</span>
        </button>
      </div>

      {/* Main Grid: Assets List (Left) vs Code & Details (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
        {/* Left Column: Asset Grid */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-lg p-3 flex flex-col space-y-3">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
            <span>Asset Disponibili ({assets.length})</span>
            <span className="text-[10px] text-slate-500">Seleziona per generare Luau</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 overflow-y-auto max-h-[480px] p-1">
            {assets.map((asset) => {
              const isSelected = selectedAsset.id === asset.id;
              return (
                <div
                  key={asset.id}
                  onClick={() => setSelectedAsset(asset)}
                  className={`group relative p-2 rounded-lg border cursor-pointer flex flex-col items-center text-center transition-all ${
                    isSelected
                      ? "bg-red-600/10 border-red-500 shadow-md shadow-red-500/10"
                      : "bg-slate-950 border-slate-800 hover:border-slate-700"
                  }`}
                >
                  <div className="w-16 h-16 rounded bg-slate-900 border border-slate-800 flex items-center justify-center p-1.5 mb-1.5 overflow-hidden">
                    <img
                      src={asset.dataUrl}
                      alt={asset.name}
                      className="max-w-full max-h-full object-contain"
                    />
                  </div>

                  <span className="text-xs font-medium text-slate-200 truncate w-full">
                    {asset.name}
                  </span>

                  <span className="text-[10px] text-slate-500 font-mono mt-0.5">
                    {asset.assetType}
                  </span>

                  {/* Delete Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteAsset(asset.id);
                    }}
                    className="absolute top-1 right-1 p-1 text-slate-500 hover:text-rose-400 opacity-0 group-hover:opacity-100 transition-opacity"
                    title="Rimuovi asset"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Asset Details & Lua Snippet */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-slate-950 border border-slate-800 p-1 flex items-center justify-center">
                <img
                  src={selectedAsset.dataUrl}
                  alt={selectedAsset.name}
                  className="max-w-full max-h-full object-contain"
                />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-slate-100">{selectedAsset.name}</h3>
                <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                  <span className="font-mono text-emerald-400">{selectedAsset.rbxIdPlaceholder}</span>
                  <span>•</span>
                  <span>{(selectedAsset.sizeBytes / 1024).toFixed(1)} KB</span>
                </div>
              </div>
            </div>

            {/* Change Target Roblox Type */}
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded border border-slate-800 text-xs">
              {(["ImageLabel", "ImageButton", "Decal", "Texture"] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setSelectedAsset({ ...selectedAsset, assetType: t })}
                  className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                    selectedAsset.assetType === t
                      ? "bg-red-600 text-white"
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => onInjectAssetToPrompt(selectedAsset)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-medium text-xs rounded shadow transition-all active:scale-95"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Includi nel Prompt AI</span>
            </button>

            <button
              onClick={() => onInsertCodeToActiveFile(currentSnippet)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded border border-slate-700 transition-colors"
            >
              <FileCode className="w-3.5 h-3.5 text-blue-400" />
              <span>Incolla nello Script Attivo</span>
            </button>

            <button
              onClick={handleCopySnippet}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded border border-slate-700 transition-colors ml-auto"
            >
              {copiedSnippet ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedSnippet ? "Copiato!" : "Copia Codice Luau"}</span>
            </button>
          </div>

          {/* Code Preview Box */}
          <div className="flex-1 bg-slate-950 rounded-lg p-3 border border-slate-800 font-mono text-xs overflow-auto">
            <pre className="text-slate-300 leading-relaxed whitespace-pre font-mono text-xs">
              {currentSnippet}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};

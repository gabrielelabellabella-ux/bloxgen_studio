import React, { useState, useRef } from "react";
import { 
  Sparkles, 
  Send, 
  Image as ImageIcon, 
  X, 
  FileCode, 
  Wand2, 
  Zap, 
  Loader2 
} from "lucide-react";
import { ScriptType } from "../types";

interface AiPromptBarProps {
  onGenerate: (prompt: string, scriptType: ScriptType, images: { data: string; mimeType: string }[]) => Promise<void>;
  isLoading: boolean;
  selectedScriptType: ScriptType;
  onChangeScriptType: (type: ScriptType) => void;
  activeFileName?: string;
}

const PROMPT_SUGGESTIONS = [
  "Crea sistema leaderstats completo con salvataggio DataStore e valuta monete",
  "Sistema di hitbox per armi da mischia con Raycast e trail particellare",
  "Crea un menù di shop responsive con categorie, bottoni e acquisti",
  "Script di dash e schivata con cooldown, effetto scia e suoni 3D",
  "Sistema di checkpoint progressivo e leaderboard per obby",
];

export const AiPromptBar: React.FC<AiPromptBarProps> = ({
  onGenerate,
  isLoading,
  selectedScriptType,
  onChangeScriptType,
  activeFileName,
}) => {
  const [prompt, setPrompt] = useState("");
  const [attachedImages, setAttachedImages] = useState<{ data: string; mimeType: string; name: string }[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setAttachedImages((prev) => [
            ...prev,
            {
              data: event.target!.result as string,
              mimeType: file.type || "image/png",
              name: file.name,
            },
          ]);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = (index: number) => {
    setAttachedImages((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || isLoading) return;
    await onGenerate(prompt, selectedScriptType, attachedImages);
    setPrompt("");
    setAttachedImages([]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 space-y-2.5 shadow-lg">
      {/* Target & Options Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 font-semibold text-slate-200">
            <Sparkles className="w-3.5 h-3.5 text-red-500" />
            <span>Generatore Luau Gemini 3.8</span>
          </div>
          {activeFileName && (
            <span className="text-[11px] text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
              Modifica: <span className="text-slate-200 font-medium">{activeFileName}</span>
            </span>
          )}
        </div>

        {/* Script Type Picker */}
        <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded border border-slate-800">
          <span className="text-[11px] text-slate-400 px-1">Tipo:</span>
          {(["Server", "LocalScript", "ModuleScript"] as ScriptType[]).map((type) => (
            <button
              key={type}
              type="button"
              onClick={() => onChangeScriptType(type)}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-all ${
                selectedScriptType === type
                  ? "bg-red-600 text-white shadow-sm"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {type === "Server" ? "Server" : type === "LocalScript" ? "LocalScript" : "ModuleScript"}
            </button>
          ))}
        </div>
      </div>

      {/* Attached Images preview badge */}
      {attachedImages.length > 0 && (
        <div className="flex items-center gap-2 flex-wrap bg-slate-950/60 p-2 rounded border border-slate-800">
          <span className="text-[11px] text-slate-400 flex items-center gap-1">
            <ImageIcon className="w-3 h-3 text-red-400" />
            Asset grafici inclusi nel prompt ({attachedImages.length}):
          </span>
          {attachedImages.map((img, idx) => (
            <div
              key={idx}
              className="flex items-center gap-1.5 bg-slate-800 text-slate-200 text-[11px] px-2 py-0.5 rounded border border-slate-700"
            >
              <img src={img.data} alt="thumb" className="w-4 h-4 object-cover rounded" />
              <span className="truncate max-w-[120px]">{img.name}</span>
              <button
                type="button"
                onClick={() => removeImage(idx)}
                className="text-slate-400 hover:text-rose-400"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Main Input Form */}
      <form onSubmit={handleSubmit} className="relative flex items-center">
        <textarea
          rows={2}
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              handleSubmit(e);
            }
          }}
          placeholder="Descrivi cosa vuoi creare o modificare in Luau (es: crea un sistema di sprint con stamina su barra GUI, oppure allega un'immagine per integrarla come texture/decal)..."
          className="w-full bg-slate-950 border border-slate-800 rounded-md pl-3 pr-24 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-red-500 resize-none font-sans"
        />

        <div className="absolute right-2 bottom-2 flex items-center gap-1">
          {/* Add Image Button */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImageUpload}
            accept="image/*"
            multiple
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="p-1.5 text-slate-400 hover:text-white rounded bg-slate-800/80 hover:bg-slate-800 transition-colors"
            title="Allega immagini o asset grafici per integrarli nel codice"
          >
            <ImageIcon className="w-4 h-4" />
          </button>

          {/* Submit Prompt */}
          <button
            type="submit"
            disabled={!prompt.trim() || isLoading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white font-medium text-xs shadow transition-all active:scale-95"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span className="hidden sm:inline">Generazione...</span>
              </>
            ) : (
              <>
                <Send className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Genera</span>
              </>
            )}
          </button>
        </div>
      </form>

      {/* Prompt Suggestions */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] scrollbar-none">
        <span className="text-slate-500 font-medium whitespace-nowrap flex items-center gap-1">
          <Zap className="w-3 h-3 text-amber-500" /> Idee:
        </span>
        {PROMPT_SUGGESTIONS.map((sug, i) => (
          <button
            key={i}
            type="button"
            onClick={() => setPrompt(sug)}
            className="whitespace-nowrap px-2 py-0.5 rounded bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800/80 transition-colors"
          >
            {sug}
          </button>
        ))}
      </div>
    </div>
  );
};

import React, { useState, useEffect } from "react";
import { 
  Sliders, 
  Sun, 
  Eye, 
  Wind, 
  Sparkles, 
  Copy, 
  Check, 
  Layers, 
  RotateCcw,
  Palette,
  Camera
} from "lucide-react";
import { LightingFxConfig } from "../types";
import { DEFAULT_LIGHTING_FX } from "../utils/defaultProject";

interface LightingFxStudioProps {
  onInsertScriptToProject: (name: string, code: string) => void;
}

const PRESETS: { id: string; name: string; desc: string; config: Partial<LightingFxConfig> }[] = [
  {
    id: "cinematic",
    name: "Cinematic Next-Gen",
    desc: "Profondità di campo realistica, motion blur morbido e raggi solari cinematografici",
    config: {
      presetName: "Cinematic Next-Gen",
      depthOfField: { enabled: true, focusDistance: 28, inFocusRadius: 18, nearIntensity: 0.35, farIntensity: 0.8 },
      motionBlur: { enabled: true, blurSize: 6, intensity: 1.1 },
      bloom: { enabled: true, intensity: 0.7, size: 22, threshold: 1.1 },
      colorCorrection: { enabled: true, brightness: 0.04, contrast: 0.18, saturation: 0.15, tintColor: "#fff8f0" },
      sunRays: { enabled: true, intensity: 0.28, spread: 0.75 },
    },
  },
  {
    id: "cyberpunk",
    name: "Cyberpunk Neon",
    desc: "Contrasto elevato, bagliori bloom accesi, tinte ciano/magenta e motion blur veloce",
    config: {
      presetName: "Cyberpunk Neon",
      depthOfField: { enabled: true, focusDistance: 20, inFocusRadius: 12, nearIntensity: 0.5, farIntensity: 0.9 },
      motionBlur: { enabled: true, blurSize: 10, intensity: 1.6 },
      bloom: { enabled: true, intensity: 1.4, size: 36, threshold: 0.8 },
      colorCorrection: { enabled: true, brightness: 0.08, contrast: 0.35, saturation: 0.45, tintColor: "#e0e7ff" },
      sunRays: { enabled: false, intensity: 0, spread: 0 },
    },
  },
  {
    id: "horror",
    name: "Horror / Grayscale Eerie",
    desc: "Desaturazione, atmosfera cupa, campo visivo ridotto e sfocatura claustrofobica",
    config: {
      presetName: "Horror Eerie",
      depthOfField: { enabled: true, focusDistance: 12, inFocusRadius: 8, nearIntensity: 0.7, farIntensity: 1.0 },
      motionBlur: { enabled: true, blurSize: 8, intensity: 1.4 },
      bloom: { enabled: true, intensity: 0.2, size: 10, threshold: 1.8 },
      colorCorrection: { enabled: true, brightness: -0.1, contrast: 0.25, saturation: -0.65, tintColor: "#94a3b8" },
      sunRays: { enabled: false, intensity: 0, spread: 0 },
    },
  },
  {
    id: "anime",
    name: "Anime Toon & Vibrant",
    desc: "Colori caldi e saturi, luce soffusa e atmosfera limpida stile animazione giapponese",
    config: {
      presetName: "Anime Toon",
      depthOfField: { enabled: true, focusDistance: 35, inFocusRadius: 25, nearIntensity: 0.2, farIntensity: 0.5 },
      motionBlur: { enabled: false, blurSize: 2, intensity: 0.5 },
      bloom: { enabled: true, intensity: 0.8, size: 26, threshold: 0.95 },
      colorCorrection: { enabled: true, brightness: 0.05, contrast: 0.12, saturation: 0.35, tintColor: "#fef08a" },
      sunRays: { enabled: true, intensity: 0.35, spread: 0.85 },
    },
  },
];

export const LightingFxStudio: React.FC<LightingFxStudioProps> = ({
  onInsertScriptToProject,
}) => {
  const [config, setConfig] = useState<LightingFxConfig>(DEFAULT_LIGHTING_FX);
  const [activePresetId, setActivePresetId] = useState<string>("cinematic");
  const [cameraSpeed, setCameraSpeed] = useState<number>(0);
  const [copied, setCopied] = useState(false);
  const [inserted, setInserted] = useState(false);

  const applyPreset = (preset: typeof PRESETS[0]) => {
    setActivePresetId(preset.id);
    setConfig((prev) => ({
      ...prev,
      ...preset.config,
    } as LightingFxConfig));
  };

  // Generate complete Luau script
  const generateLuauScript = (): string => {
    return `--!strict
-- ServerScriptService.SetupLightingFX
-- Configurazione avanzata di post-processing ed effetti visivi (Motion Blur, Depth of Field, Bloom, SunRays)

local Lighting = game:GetService("Lighting")

-- 1. Proprietà Generali Lighting
Lighting.Technology = Enum.Technology.${config.lightingProps.technology}
Lighting.Brightness = ${config.lightingProps.brightness}
Lighting.ClockTime = ${config.lightingProps.clockTime}
Lighting.ExposureCompensation = ${config.lightingProps.exposureCompensation}

-- 2. DepthOfFieldEffect (Profondità di Campo)
${
  config.depthOfField.enabled
    ? `local dof = Lighting:FindFirstChild("DepthOfField") or Instance.new("DepthOfFieldEffect")
dof.Name = "DepthOfField"
dof.FocusDistance = ${config.depthOfField.focusDistance}
dof.InFocusRadius = ${config.depthOfField.inFocusRadius}
dof.NearIntensity = ${config.depthOfField.nearIntensity}
dof.FarIntensity = ${config.depthOfField.farIntensity}
dof.Enabled = true
dof.Parent = Lighting`
    : `-- DepthOfField disabilitato`
}

-- 3. BloomEffect
${
  config.bloom.enabled
    ? `local bloom = Lighting:FindFirstChild("Bloom") or Instance.new("BloomEffect")
bloom.Name = "Bloom"
bloom.Intensity = ${config.bloom.intensity}
bloom.Size = ${config.bloom.size}
bloom.Threshold = ${config.bloom.threshold}
bloom.Enabled = true
bloom.Parent = Lighting`
    : `-- Bloom disabilitato`
}

-- 4. ColorCorrectionEffect
${
  config.colorCorrection.enabled
    ? `local colorCorrection = Lighting:FindFirstChild("ColorCorrection") or Instance.new("ColorCorrectionEffect")
colorCorrection.Name = "ColorCorrection"
colorCorrection.Brightness = ${config.colorCorrection.brightness}
colorCorrection.Contrast = ${config.colorCorrection.contrast}
colorCorrection.Saturation = ${config.colorCorrection.saturation}
colorCorrection.TintColor = Color3.fromHex("${config.colorCorrection.tintColor}")
colorCorrection.Enabled = true
colorCorrection.Parent = Lighting`
    : `-- ColorCorrection disabilitato`
}

-- 5. SunRaysEffect
${
  config.sunRays.enabled
    ? `local sunRays = Lighting:FindFirstChild("SunRays") or Instance.new("SunRaysEffect")
sunRays.Name = "SunRays"
sunRays.Intensity = ${config.sunRays.intensity}
sunRays.Spread = ${config.sunRays.spread}
sunRays.Enabled = true
sunRays.Parent = Lighting`
    : `-- SunRays disabilitato`
}

-- 6. Dynamic Camera Motion Blur (LocalScript complementare da inserire in StarterPlayerScripts)
--[[
-- StarterPlayerScripts.MotionBlurController (Client)
local RunService = game:GetService("RunService")
local Lighting = game:GetService("Lighting")
local camera = workspace.CurrentCamera

local blur = Instance.new("BlurEffect")
blur.Name = "DynamicMotionBlur"
blur.Size = 0
blur.Parent = Lighting

local lastCFrame = camera.CFrame

RunService.RenderStepped:Connect(function(dt)
	local currentCFrame = camera.CFrame
	local delta = (currentCFrame.Position - lastCFrame.Position).Magnitude
	local angle = math.acos(math.clamp(currentCFrame.LookVector:Dot(lastCFrame.LookVector), -1, 1))
	local velocity = (delta / dt) + (angle * 45)
	
	-- Calcola intensità del motion blur dinamico
	local targetSize = math.clamp(velocity * ${(config.motionBlur.intensity * 0.4).toFixed(2)}, 0, ${config.motionBlur.blurSize})
	blur.Size = blur.Size + (targetSize - blur.Size) * 0.2
	lastCFrame = currentCFrame
end)
]]

print("[Lighting] Preset visuale '${config.presetName}' applicato con successo!")
`;
  };

  const currentScript = generateLuauScript();

  const handleCopy = () => {
    navigator.clipboard.writeText(currentScript);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleInsert = () => {
    onInsertScriptToProject("SetupLightingFX", currentScript);
    setInserted(true);
    setTimeout(() => setInserted(false), 2500);
  };

  // Simulated Blur radius calculation from camera speed + motion blur settings
  const simulatedMotionBlur = config.motionBlur.enabled
    ? (cameraSpeed / 100) * config.motionBlur.blurSize
    : 0;

  return (
    <div className="flex-1 flex flex-col bg-slate-950 p-4 space-y-4 overflow-y-auto">
      {/* Title & Overview Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-amber-500" />
            <h2 className="text-base font-semibold text-slate-100">
              Roblox Lighting & Post-Processing FX Studio
            </h2>
            <span className="text-[10px] bg-amber-500/10 text-amber-400 font-mono px-2 py-0.5 rounded border border-amber-500/20">
              Motion Blur & Depth of Field
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Simula e genera istantaneamente configurazioni grafiche professionali per Roblox Studio:
            effetto <strong className="text-amber-400">Depth of Field</strong> (profondità di fuoco),
            <strong className="text-amber-400"> Motion Blur dinamico</strong> calcolato sulla velocità della telecamera,
            Bloom cinematografico e Color Grading.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded border border-slate-700 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? "Copiato!" : "Copia Script Luau"}</span>
          </button>

          <button
            onClick={handleInsert}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white text-xs font-semibold rounded shadow transition-all active:scale-95"
          >
            {inserted ? <Check className="w-3.5 h-3.5" /> : <Layers className="w-3.5 h-3.5" />}
            <span>{inserted ? "Inserito nel Progetto!" : "Inserisci nel Progetto"}</span>
          </button>
        </div>
      </div>

      {/* Preset Chips */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {PRESETS.map((p) => (
          <button
            key={p.id}
            onClick={() => applyPreset(p)}
            className={`p-3 rounded-lg border text-left transition-all ${
              activePresetId === p.id
                ? "bg-amber-500/10 border-amber-500 shadow-md shadow-amber-500/10 text-amber-200"
                : "bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-300"
            }`}
          >
            <div className="font-semibold text-xs text-slate-100 flex items-center justify-between">
              <span>{p.name}</span>
              {activePresetId === p.id && <Check className="w-3.5 h-3.5 text-amber-400" />}
            </div>
            <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">{p.desc}</p>
          </button>
        ))}
      </div>

      {/* Interactive Simulation Viewport + Fine Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
        {/* Viewport Simulation (Left) */}
        <div className="lg:col-span-6 bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-200 flex items-center gap-1.5">
              <Eye className="w-4 h-4 text-amber-400" />
              Simulatore Post-Processing Roblox
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              Future Lighting Engine
            </span>
          </div>

          {/* Interactive 3D/Canvas Simulation Box */}
          <div
            className="relative h-64 rounded-xl overflow-hidden border border-slate-800 shadow-inner flex flex-col items-center justify-center select-none"
            style={{
              filter: `
                brightness(${1 + config.colorCorrection.brightness})
                contrast(${1 + config.colorCorrection.contrast})
                saturate(${1 + config.colorCorrection.saturation})
              `,
            }}
          >
            {/* Background 3D Horizon & Sky */}
            <div className="absolute inset-0 bg-gradient-to-b from-indigo-950 via-slate-900 to-amber-950/40"></div>

            {/* Simulated Sun Rays */}
            {config.sunRays.enabled && (
              <div
                className="absolute -top-10 left-1/4 w-96 h-96 pointer-events-none rounded-full"
                style={{
                  background: `radial-gradient(circle, rgba(255,230,150,${config.sunRays.intensity * 1.5}) 0%, transparent 70%)`,
                  filter: "blur(20px)",
                }}
              ></div>
            )}

            {/* Depth Of Field Near Plane (Blurred) */}
            {config.depthOfField.enabled && (
              <div
                className="absolute -bottom-8 -left-8 w-40 h-40 bg-slate-800/80 rounded-2xl border border-slate-700 pointer-events-none"
                style={{
                  filter: `blur(${config.depthOfField.nearIntensity * 12}px)`,
                  transform: "rotate(15deg)",
                }}
              ></div>
            )}

            {/* In-Focus Character Model Placeholder */}
            <div
              className="relative z-10 flex flex-col items-center p-4 rounded-xl bg-slate-800/60 border border-slate-600/50 shadow-2xl transition-all"
              style={{
                filter: `blur(${simulatedMotionBlur}px)`,
              }}
            >
              <div className="w-12 h-12 rounded-lg bg-gradient-to-tr from-amber-500 to-red-500 flex items-center justify-center text-white font-bold text-lg shadow-lg">
                R
              </div>
              <span className="text-xs font-semibold text-slate-100 mt-2">Roblox Character</span>
              <span className="text-[10px] text-amber-300 font-mono">
                {config.depthOfField.enabled ? "Piano Focale (A Fuoco)" : "Nessun DOF"}
              </span>
            </div>

            {/* Depth Of Field Far Plane (Blurred Background Objects) */}
            {config.depthOfField.enabled && (
              <div
                className="absolute top-8 right-12 w-28 h-28 bg-emerald-800/40 rounded-full pointer-events-none"
                style={{
                  filter: `blur(${config.depthOfField.farIntensity * 16}px)`,
                }}
              ></div>
            )}

            {/* Bloom Glow on lights */}
            {config.bloom.enabled && (
              <div
                className="absolute top-12 left-10 w-8 h-8 rounded-full bg-cyan-400 pointer-events-none"
                style={{
                  boxShadow: `0 0 ${config.bloom.size * 2}px ${config.bloom.intensity * 18}px rgba(56, 189, 248, ${config.bloom.intensity})`,
                }}
              ></div>
            )}
          </div>

          {/* Interactive Motion Blur Slider */}
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                <Camera className="w-3.5 h-3.5 text-amber-400" />
                Test Velocità Telecamera (Motion Blur dinamico):
              </span>
              <span className="font-mono text-amber-400 font-bold">{cameraSpeed}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={cameraSpeed}
              onChange={(e) => setCameraSpeed(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
            <p className="text-[11px] text-slate-500">
              Muovi lo slider per simulare la rotazione rapida della visuale del giocatore in gioco.
            </p>
          </div>
        </div>

        {/* Sliders & Parameters Fine Tuning (Right) */}
        <div className="lg:col-span-6 bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col space-y-4">
          <span className="font-semibold text-xs text-slate-200 border-b border-slate-800 pb-2">
            Regolazione Parametri Roblox Lighting
          </span>

          <div className="space-y-3.5 overflow-y-auto max-h-[460px] pr-1 text-xs">
            {/* 1. Depth of Field Controls */}
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-200">DepthOfFieldEffect</span>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.depthOfField.enabled}
                    onChange={(e) =>
                      setConfig({
                        ...config,
                        depthOfField: { ...config.depthOfField, enabled: e.target.checked },
                      })
                    }
                    className="accent-amber-500"
                  />
                  <span className="text-[11px] text-slate-400">Attivo</span>
                </label>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>FocusDistance:</span>
                    <span className="font-mono text-amber-400">{config.depthOfField.focusDistance} studs</span>
                  </div>
                  <input
                    type="range"
                    min={5}
                    max={80}
                    value={config.depthOfField.focusDistance}
                    onChange={(e) =>
                      setConfig({
                        ...config,
                        depthOfField: { ...config.depthOfField, focusDistance: Number(e.target.value) },
                      })
                    }
                    className="w-full accent-amber-500"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>InFocusRadius:</span>
                    <span className="font-mono text-amber-400">{config.depthOfField.inFocusRadius} studs</span>
                  </div>
                  <input
                    type="range"
                    min={2}
                    max={40}
                    value={config.depthOfField.inFocusRadius}
                    onChange={(e) =>
                      setConfig({
                        ...config,
                        depthOfField: { ...config.depthOfField, inFocusRadius: Number(e.target.value) },
                      })
                    }
                    className="w-full accent-amber-500"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>NearIntensity:</span>
                    <span className="font-mono text-amber-400">{config.depthOfField.nearIntensity}</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.05}
                    value={config.depthOfField.nearIntensity}
                    onChange={(e) =>
                      setConfig({
                        ...config,
                        depthOfField: { ...config.depthOfField, nearIntensity: Number(e.target.value) },
                      })
                    }
                    className="w-full accent-amber-500"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>FarIntensity:</span>
                    <span className="font-mono text-amber-400">{config.depthOfField.farIntensity}</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.05}
                    value={config.depthOfField.farIntensity}
                    onChange={(e) =>
                      setConfig({
                        ...config,
                        depthOfField: { ...config.depthOfField, farIntensity: Number(e.target.value) },
                      })
                    }
                    className="w-full accent-amber-500"
                  />
                </div>
              </div>
            </div>

            {/* 2. Motion Blur Controls */}
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-200">Motion Blur Dinamico</span>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.motionBlur.enabled}
                    onChange={(e) =>
                      setConfig({
                        ...config,
                        motionBlur: { ...config.motionBlur, enabled: e.target.checked },
                      })
                    }
                    className="accent-amber-500"
                  />
                  <span className="text-[11px] text-slate-400">Attivo</span>
                </label>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>BlurSize Massimo:</span>
                    <span className="font-mono text-amber-400">{config.motionBlur.blurSize} px</span>
                  </div>
                  <input
                    type="range"
                    min={2}
                    max={20}
                    value={config.motionBlur.blurSize}
                    onChange={(e) =>
                      setConfig({
                        ...config,
                        motionBlur: { ...config.motionBlur, blurSize: Number(e.target.value) },
                      })
                    }
                    className="w-full accent-amber-500"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Sensibilità Telecamera:</span>
                    <span className="font-mono text-amber-400">{config.motionBlur.intensity}x</span>
                  </div>
                  <input
                    type="range"
                    min={0.5}
                    max={3.0}
                    step={0.1}
                    value={config.motionBlur.intensity}
                    onChange={(e) =>
                      setConfig({
                        ...config,
                        motionBlur: { ...config.motionBlur, intensity: Number(e.target.value) },
                      })
                    }
                    className="w-full accent-amber-500"
                  />
                </div>
              </div>
            </div>

            {/* 3. Bloom & Color Correction */}
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-200">Bloom & ColorCorrection</span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Bloom Intensity:</span>
                    <span className="font-mono text-amber-400">{config.bloom.intensity}</span>
                  </div>
                  <input
                    type="range"
                    min={0.1}
                    max={2.0}
                    step={0.05}
                    value={config.bloom.intensity}
                    onChange={(e) =>
                      setConfig({
                        ...config,
                        bloom: { ...config.bloom, intensity: Number(e.target.value) },
                      })
                    }
                    className="w-full accent-amber-500"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Saturazione:</span>
                    <span className="font-mono text-amber-400">{config.colorCorrection.saturation}</span>
                  </div>
                  <input
                    type="range"
                    min={-1.0}
                    max={1.0}
                    step={0.05}
                    value={config.colorCorrection.saturation}
                    onChange={(e) =>
                      setConfig({
                        ...config,
                        colorCorrection: { ...config.colorCorrection, saturation: Number(e.target.value) },
                      })
                    }
                    className="w-full accent-amber-500"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import { ProjectFile, DevicePreset, LightingFxConfig } from "../types";

export const DEFAULT_DEVICE_PRESETS: DevicePreset[] = [
  { id: "pc-1080p", name: "PC / Desktop (1080p)", category: "Desktop", width: 1920, height: 1080, aspectRatioLabel: "16:9" },
  { id: "pc-1440p", name: "PC Ultra (1440p)", category: "Desktop", width: 2560, height: 1440, aspectRatioLabel: "16:9" },
  { id: "iphone-15", name: "iPhone 15 Pro", category: "Mobile", width: 393, height: 852, aspectRatioLabel: "19.5:9", isPortrait: false },
  { id: "samsung-s24", name: "Samsung Galaxy S24", category: "Mobile", width: 360, height: 780, aspectRatioLabel: "19.5:9", isPortrait: false },
  { id: "ipad-air", name: "iPad Air (10.9\")", category: "Tablet", width: 820, height: 1180, aspectRatioLabel: "4:3", isPortrait: false },
  { id: "console-tv", name: "Console / TV", category: "Console", width: 1920, height: 1080, aspectRatioLabel: "16:9" },
];

export const DEFAULT_LIGHTING_FX: LightingFxConfig = {
  presetName: "Cinematic Next-Gen",
  depthOfField: {
    enabled: true,
    focusDistance: 30,
    inFocusRadius: 18,
    nearIntensity: 0.35,
    farIntensity: 0.8,
  },
  motionBlur: {
    enabled: true,
    blurSize: 7,
    intensity: 1.2,
  },
  bloom: {
    enabled: true,
    intensity: 0.65,
    size: 22,
    threshold: 1.1,
  },
  colorCorrection: {
    enabled: true,
    brightness: 0.04,
    contrast: 0.18,
    saturation: 0.15,
    tintColor: "#fff8f0",
  },
  sunRays: {
    enabled: true,
    intensity: 0.28,
    spread: 0.75,
  },
  atmosphere: {
    enabled: true,
    density: 0.38,
    offset: 0.25,
    haze: 1.5,
    color: "#c8d6e5",
  },
  lightingProps: {
    technology: "Future",
    clockTime: 17.2,
    brightness: 2.8,
    exposureCompensation: 0.15,
  },
};

export const INITIAL_PROJECT_FILES: ProjectFile[] = [
  {
    id: "server-combat-manager",
    name: "CombatSystem",
    type: "Server",
    parentPath: "ServerScriptService",
    description: "Gestione server-side di combattimento, hitbox con raycasting e validazione dei danni",
    modifiedAt: Date.now(),
    content: `--!strict
-- ServerScriptService.CombatSystem
-- Gestore autorevole del combattimento e calcolo danni

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Debris = game:GetService("Debris")

-- Cache eventi remoti in ReplicatedStorage
local Remotes = ReplicatedStorage:FindFirstChild("CombatRemotes")
if not Remotes then
	local folder = Instance.new("Folder")
	folder.Name = "CombatRemotes"
	folder.Parent = ReplicatedStorage
	Remotes = folder
end

local AttackEvent = Remotes:FindFirstChild("AttackEvent") :: RemoteEvent
if not AttackEvent then
	local event = Instance.new("RemoteEvent")
	event.Name = "AttackEvent"
	event.Parent = Remotes
	AttackEvent = event
end

local COOLDOWN_SECONDS = 0.45
local BASE_DAMAGE = 25
local MAX_ATTACK_DISTANCE = 14

local lastAttackMap: { [number]: number } = {}

local function validateAttack(player: Player, targetPart: BasePart?): boolean
	if not targetPart or not targetPart.Parent then return false end
	local character = player.Character
	if not character then return false end
	
	local root = character:FindFirstChild("HumanoidRootPart") :: BasePart?
	if not root then return false end
	
	-- Verifica distanza per prevenire exploit di range
	local distance = (root.Position - targetPart.Position).Magnitude
	if distance > MAX_ATTACK_DISTANCE then
		warn(string.format("[Anti-Exploit] %s ha tentato un attacco a distanza eccessiva: %.2f", player.Name, distance))
		return false
	end
	
	return true
end

local function onAttackTriggered(player: Player, targetHitbox: BasePart)
	local now = os.clock()
	local lastTime = lastAttackMap[player.UserId] or 0
	
	if (now - lastTime) < COOLDOWN_SECONDS then
		return -- Attacco in cooldown
	end
	lastAttackMap[player.UserId] = now
	
	if not validateAttack(player, targetHitbox) then
		return
	end
	
	local targetModel = targetHitbox.Parent
	local targetHumanoid = targetModel:FindFirstChildOfClass("Humanoid")
	if targetHumanoid and targetHumanoid.Health > 0 then
		targetHumanoid:TakeDamage(BASE_DAMAGE)
		
		-- Feedback particellare e audio
		print(string.format("[Combat] %s ha inflitto %d danni a %s", player.Name, BASE_DAMAGE, targetModel.Name))
	end
end

AttackEvent.OnServerEvent:Connect(onAttackTriggered)

Players.PlayerRemoving:Connect(function(player)
	lastAttackMap[player.UserId] = nil
end)
`,
  },
  {
    id: "module-inventory",
    name: "InventoryManager",
    type: "ModuleScript",
    parentPath: "ReplicatedStorage",
    description: "Modulo universale per gestione slot inventario, stacking e metadata oggetti",
    modifiedAt: Date.now(),
    content: `--!strict
-- ReplicatedStorage.InventoryManager
-- Modulo OOP per inventario scalabile

export type ItemData = {
	Id: string,
	Name: string,
	Rarity: "Common" | "Rare" | "Epic" | "Legendary",
	MaxStack: number,
	IconAssetId: string,
}

local InventoryManager = {}
InventoryManager.__index = InventoryManager

function InventoryManager.new(maxSlots: number)
	local self = setmetatable({}, InventoryManager)
	self.MaxSlots = maxSlots or 20
	self.Slots = {}
	return self
end

function InventoryManager:AddItem(item: ItemData, amount: number): boolean
	local qty = amount or 1
	-- Cerca stack esistente
	for i = 1, self.MaxSlots do
		local slot = self.Slots[i]
		if slot and slot.Item.Id == item.Id and (slot.Quantity + qty) <= item.MaxStack then
			slot.Quantity += qty
			return true
		end
	end
	
	-- Cerca primo slot libero
	for i = 1, self.MaxSlots do
		if not self.Slots[i] then
			self.Slots[i] = { Item = item, Quantity = qty }
			return true
		end
	end
	
	return false -- Inventario pieno
end

function InventoryManager:GetSlot(index: number)
	return self.Slots[index]
end

return InventoryManager
`,
  },
  {
    id: "client-hud-controller",
    name: "ResponsiveHudController",
    type: "LocalScript",
    parentPath: "StarterGui",
    description: "Controller UI responsive per barre salute/energia e pulsanti adattivi multi-device",
    modifiedAt: Date.now(),
    content: `--!strict
-- StarterGui.ResponsiveHudController
-- Calcolo dinamico dello scaling UI con UDim2.fromScale e UIAspectRatioConstraint

local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")

local localPlayer = Players.LocalPlayer
local playerGui = localPlayer:WaitForChild("PlayerGui")

local screenGui = Instance.new("ScreenGui")
screenGui.Name = "BloxGenMainHUD"
screenGui.ResetOnSpawn = false
screenGui.IgnoreGuiInset = false
screenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
screenGui.Parent = playerGui

-- Frame principale ancorato in basso al centro
local hudFrame = Instance.new("Frame")
hudFrame.Name = "HudContainer"
hudFrame.AnchorPoint = Vector2.new(0.5, 1)
-- Dimensioni scalate in percentuale (45% larghezza schermo, 8% altezza)
hudFrame.Position = UDim2.fromScale(0.5, 0.96)
hudFrame.Size = UDim2.fromScale(0.45, 0.08)
hudFrame.BackgroundColor3 = Color3.fromRGB(20, 24, 34)
hudFrame.BackgroundTransparency = 0.15
hudFrame.Parent = screenGui

local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0.25, 0)
corner.Parent = hudFrame

local stroke = Instance.new("UIStroke")
stroke.Color = Color3.fromRGB(59, 130, 246)
stroke.Thickness = 2
stroke.Transparency = 0.3
stroke.Parent = hudFrame

-- Barra Salute con UDim2.fromScale per responsive fill
local healthBg = Instance.new("Frame")
healthBg.Name = "HealthBackground"
healthBg.AnchorPoint = Vector2.new(0, 0.5)
healthBg.Position = UDim2.fromScale(0.04, 0.5)
healthBg.Size = UDim2.fromScale(0.60, 0.55)
healthBg.BackgroundColor3 = Color3.fromRGB(30, 35, 48)
healthBg.Parent = hudFrame

local healthBgCorner = Instance.new("UICorner")
healthBgCorner.CornerRadius = UDim.new(0.5, 0)
healthBgCorner.Parent = healthBg

local healthFill = Instance.new("Frame")
healthFill.Name = "HealthFill"
healthFill.Size = UDim2.fromScale(1.0, 1.0)
healthFill.BackgroundColor3 = Color3.fromRGB(34, 197, 94)
healthFill.Parent = healthBg

local fillCorner = Instance.new("UICorner")
fillCorner.CornerRadius = UDim.new(0.5, 0)
fillCorner.Parent = healthFill

-- Testo indicatore HP
local healthLabel = Instance.new("TextLabel")
healthLabel.Size = UDim2.fromScale(1, 1)
healthLabel.BackgroundTransparency = 1
healthLabel.Text = "HP: 100 / 100"
healthLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
healthLabel.TextScaled = true
healthLabel.Font = Enum.Font.GothamBold
healthLabel.Parent = healthBg

-- Adatta la UI se su Mobile (touchscreen)
if UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled then
	-- Ingrandisci i target touch per schermi piccoli
	hudFrame.Size = UDim2.fromScale(0.75, 0.11)
end

print("[BloxGen] HUD Responsive inizializzato con successo!")
`,
  },
  {
    id: "lighting-setup-script",
    name: "SetupLightingEffects",
    type: "Server",
    parentPath: "ServerScriptService",
    description: "Installazione automatica degli effetti DepthOfField, Bloom, SunRays e ColorCorrection in Lighting",
    modifiedAt: Date.now(),
    content: `--!strict
-- ServerScriptService.SetupLightingEffects
-- Iniezione degli effetti grafici avanzati in Lighting

local Lighting = game:GetService("Lighting")

-- Imposta Lighting moderno
Lighting.Technology = Enum.Technology.Future
Lighting.Brightness = 2.6
Lighting.ClockTime = 17.2
Lighting.ExposureCompensation = 0.12

-- 1. Depth Of Field
local dof = Lighting:FindFirstChildOfClass("DepthOfFieldEffect") or Instance.new("DepthOfFieldEffect")
dof.Name = "CinematicDepthOfField"
dof.FocusDistance = 28
dof.InFocusRadius = 16
dof.NearIntensity = 0.35
dof.FarIntensity = 0.75
dof.Enabled = true
dof.Parent = Lighting

-- 2. Bloom
local bloom = Lighting:FindFirstChildOfClass("BloomEffect") or Instance.new("BloomEffect")
bloom.Name = "CinematicBloom"
bloom.Intensity = 0.7
bloom.Size = 22
bloom.Threshold = 1.1
bloom.Enabled = true
bloom.Parent = Lighting

-- 3. ColorCorrection
local cc = Lighting:FindFirstChildOfClass("ColorCorrectionEffect") or Instance.new("ColorCorrectionEffect")
cc.Name = "CinematicColorCorrection"
cc.Brightness = 0.04
cc.Contrast = 0.18
cc.Saturation = 0.15
cc.TintColor = Color3.fromRGB(255, 248, 240)
cc.Enabled = true
cc.Parent = Lighting

-- 4. SunRays
local sunRays = Lighting:FindFirstChildOfClass("SunRaysEffect") or Instance.new("SunRaysEffect")
sunRays.Name = "CinematicSunRays"
sunRays.Intensity = 0.25
sunRays.Spread = 0.8
sunRays.Enabled = true
sunRays.Parent = Lighting

print("[Lighting] Effetti cinematografici caricati con successo.")
`,
  },
];

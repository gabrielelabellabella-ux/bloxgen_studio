import { SyntaxIssue } from "../types";

export function analyzeLuauSyntax(code: string): SyntaxIssue[] {
  const issues: SyntaxIssue[] = [];
  const lines = code.split("\n");

  let blockDepth = 0;
  const blockStack: { type: string; line: number }[] = [];

  let inMultilineComment = false;
  let inMultilineString = false;

  for (let i = 0; i < lines.length; i++) {
    const lineNum = i + 1;
    const rawLine = lines[i];
    const trimmed = rawLine.trim();

    // Check multiline comment tags
    if (trimmed.includes("--[[")) inMultilineComment = true;
    if (inMultilineComment) {
      if (trimmed.includes("]]")) inMultilineComment = false;
      continue;
    }

    // Single line comment
    const codePart = rawLine.split("--")[0];
    if (!codePart.trim()) continue;

    // Check multiline strings
    if (codePart.includes("[[")) inMultilineString = true;
    if (inMultilineString) {
      if (codePart.includes("]]")) inMultilineString = false;
      continue;
    }

    // Deprecated Roblox methods checks
    if (/\bwait\s*\(/g.test(codePart) && !codePart.includes("task.wait")) {
      issues.push({
        line: lineNum,
        severity: "warning",
        message: "Uso di 'wait()' globale deprecato.",
        suggestion: "Sostituisci con 'task.wait()' per un scheduling a 60Hz senza ritardi del frame.",
      });
    }

    if (/\bspawn\s*\(/g.test(codePart) && !codePart.includes("task.spawn")) {
      issues.push({
        line: lineNum,
        severity: "warning",
        message: "Uso di 'spawn()' deprecato.",
        suggestion: "Sostituisci con 'task.spawn()' o 'task.defer()' per evitare overhead e delay di thread.",
      });
    }

    if (/:connect\s*\(/g.test(codePart)) {
      issues.push({
        line: lineNum,
        severity: "error",
        message: "Metodo ':connect()' con la 'c' minuscola è deprecato o non supportato in Luau.",
        suggestion: "Usa ':Connect()' con la C maiuscola.",
      });
    }

    if (/:findFirstChild\s*\(/g.test(codePart)) {
      issues.push({
        line: lineNum,
        severity: "warning",
        message: "Metodo ':findFirstChild()' deprecato.",
        suggestion: "Usa ':FindFirstChild()'.",
      });
    }

    if (/:waitForChild\s*\(/g.test(codePart)) {
      issues.push({
        line: lineNum,
        severity: "warning",
        message: "Metodo ':waitForChild()' deprecato.",
        suggestion: "Usa ':WaitForChild()'.",
      });
    }

    // Check unclosed quotes on single line
    let singleQuotes = 0;
    let doubleQuotes = 0;
    let escaped = false;
    for (let c = 0; c < codePart.length; c++) {
      const char = codePart[c];
      if (char === "\\" && !escaped) {
        escaped = true;
        continue;
      }
      if (!escaped) {
        if (char === "'") singleQuotes++;
        if (char === '"') doubleQuotes++;
      }
      escaped = false;
    }
    if (singleQuotes % 2 !== 0 || doubleQuotes % 2 !== 0) {
      issues.push({
        line: lineNum,
        severity: "error",
        message: "Stringa non terminata nella riga.",
        suggestion: "Chiudi le virgolette aperte (' o \").",
      });
    }

    // Match blocks in codePart
    // Keywords starting a block: function, if ... then, for ... do, while ... do, do
    const tokens = codePart.split(/\b/);
    for (let t = 0; t < tokens.length; t++) {
      const tok = tokens[t];

      if (tok === "function" || tok === "do" || tok === "then") {
        blockDepth++;
        blockStack.push({ type: tok, line: lineNum });
      } else if (tok === "end") {
        if (blockDepth > 0) {
          blockDepth--;
          blockStack.pop();
        } else {
          issues.push({
            line: lineNum,
            severity: "error",
            message: "Parola chiave 'end' inattesa senza blocco aperto.",
            suggestion: "Rimuovi questo 'end' in eccesso o controlla l'apertura del blocco.",
          });
        }
      }
    }
  }

  if (blockDepth > 0 && blockStack.length > 0) {
    const lastOpen = blockStack[blockStack.length - 1];
    issues.push({
      line: lastOpen.line,
      severity: "error",
      message: `Blocco '${lastOpen.type}' aperto alla riga ${lastOpen.line} non è stato chiuso.`,
      suggestion: `Aggiungi 'end' per chiudere il blocco prima della fine del file. (Blocchi ancora aperti: ${blockDepth})`,
    });
  }

  return issues;
}

export interface HighlightToken {
  text: string;
  type: "keyword" | "builtin" | "string" | "comment" | "number" | "operator" | "plain";
}

const LUAU_KEYWORDS = new Set([
  "and", "break", "do", "else", "elseif", "end", "false", "for", "function",
  "if", "in", "local", "nil", "not", "or", "repeat", "return", "then",
  "true", "until", "while", "type", "export", "continue"
]);

const ROBLOX_BUILTINS = new Set([
  "game", "workspace", "script", "Instance", "Vector3", "CFrame", "Color3",
  "UDim2", "UDim", "BrickColor", "math", "table", "string", "task",
  "TweenService", "Players", "ReplicatedStorage", "ServerScriptService",
  "StarterGui", "Lighting", "Debris", "UserInputService", "RunService",
  "print", "warn", "error", "typeof", "pcall", "require", "pairs", "ipairs"
]);

export function tokenizeLuauLine(line: string): HighlightToken[] {
  const tokens: HighlightToken[] = [];
  let idx = 0;

  while (idx < line.length) {
    // Comment
    if (line.slice(idx, idx + 2) === "--") {
      tokens.push({ text: line.slice(idx), type: "comment" });
      break;
    }

    // String single/double
    if (line[idx] === '"' || line[idx] === "'") {
      const quote = line[idx];
      let endIdx = idx + 1;
      let escaped = false;
      while (endIdx < line.length) {
        if (line[endIdx] === "\\" && !escaped) {
          escaped = true;
          endIdx++;
          continue;
        }
        if (line[endIdx] === quote && !escaped) {
          endIdx++;
          break;
        }
        escaped = false;
        endIdx++;
      }
      tokens.push({ text: line.slice(idx, endIdx), type: "string" });
      idx = endIdx;
      continue;
    }

    // Number
    const numMatch = line.slice(idx).match(/^-?\d+(\.\d+)?/);
    if (numMatch && numMatch.index === 0) {
      tokens.push({ text: numMatch[0], type: "number" });
      idx += numMatch[0].length;
      continue;
    }

    // Identifiers & words
    const wordMatch = line.slice(idx).match(/^[a-zA-Z_][a-zA-Z0-9_]*/);
    if (wordMatch && wordMatch.index === 0) {
      const word = wordMatch[0];
      if (LUAU_KEYWORDS.has(word)) {
        tokens.push({ text: word, type: "keyword" });
      } else if (ROBLOX_BUILTINS.has(word)) {
        tokens.push({ text: word, type: "builtin" });
      } else {
        tokens.push({ text: word, type: "plain" });
      }
      idx += word.length;
      continue;
    }

    // Operators & punctuation
    const opMatch = line.slice(idx).match(/^[+\-*/%^#=~<>:,.;()[\]{}]/);
    if (opMatch && opMatch.index === 0) {
      tokens.push({ text: opMatch[0], type: "operator" });
      idx += opMatch[0].length;
      continue;
    }

    // Whitespace / other
    tokens.push({ text: line[idx], type: "plain" });
    idx++;
  }

  return tokens;
}

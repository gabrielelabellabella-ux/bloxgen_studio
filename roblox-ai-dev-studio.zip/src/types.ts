export type ScriptType = "Server" | "LocalScript" | "ModuleScript";

export interface ProjectFile {
  id: string;
  name: string;
  type: ScriptType | "Folder" | "ScreenGui" | "LightingConfig" | "Asset";
  parentPath: string; // e.g. "ServerScriptService", "StarterGui", "ReplicatedStorage"
  content: string;
  description?: string;
  icon?: string;
  children?: string[]; // IDs of children files
  modifiedAt?: number;
}

export interface SyntaxIssue {
  line: number;
  column?: number;
  severity: "error" | "warning" | "info";
  message: string;
  suggestion?: string;
}

export interface UiElementData {
  id: string;
  name: string;
  type: "Frame" | "ImageLabel" | "TextLabel" | "ImageButton" | "TextButton" | "ScrollingFrame";
  position: { xScale: number; yScale: number; xOffset?: number; yOffset?: number };
  size: { xScale: number; yScale: number; xOffset?: number; yOffset?: number };
  anchorPoint?: { x: number; y: number };
  backgroundColor?: string;
  backgroundTransparency?: number;
  text?: string;
  textColor?: string;
  textSize?: number;
  font?: string;
  cornerRadius?: number;
  strokeColor?: string;
  strokeThickness?: number;
  imageSrc?: string;
  aspectRatio?: number;
  children?: UiElementData[];
}

export interface DevicePreset {
  id: string;
  name: string;
  category: "Desktop" | "Mobile" | "Tablet" | "Console";
  width: number;
  height: number;
  aspectRatioLabel: string;
  isPortrait?: boolean;
}

export interface GraphicAsset {
  id: string;
  name: string;
  dataUrl: string;
  mimeType: string;
  sizeBytes: number;
  assetType: "Decal" | "ImageLabel" | "ImageButton" | "Texture" | "Icon";
  rbxIdPlaceholder: string;
}

export interface LightingFxConfig {
  presetName: string;
  depthOfField: {
    enabled: boolean;
    focusDistance: number;
    inFocusRadius: number;
    nearIntensity: number;
    farIntensity: number;
  };
  motionBlur: {
    enabled: boolean;
    blurSize: number;
    intensity: number;
  };
  bloom: {
    enabled: boolean;
    intensity: number;
    size: number;
    threshold: number;
  };
  colorCorrection: {
    enabled: boolean;
    brightness: number;
    contrast: number;
    saturation: number;
    tintColor: string;
  };
  sunRays: {
    enabled: boolean;
    intensity: number;
    spread: number;
  };
  atmosphere: {
    enabled: boolean;
    density: number;
    offset: number;
    haze: number;
    color: string;
  };
  lightingProps: {
    technology: "Future" | "ShadowMap" | "Voxel" | "Compatibility";
    clockTime: number;
    brightness: number;
    exposureCompensation: number;
  };
}

export interface RobloxStudioSession {
  connected: boolean;
  placeName: string;
  placeId: number;
  studioVersion?: string;
  lastHeartbeat: number;
  autoSync: boolean;
  pingMs?: number;
}

export interface StudioLogEntry {
  id: string;
  timestamp: number;
  level: "info" | "warning" | "error";
  message: string;
  stackTrace?: string;
}

export interface StudioSyncFilePayload {
  name: string;
  type: ScriptType | "ScreenGui" | "Folder" | "LightingConfig";
  parentPath: string;
  content: string;
}

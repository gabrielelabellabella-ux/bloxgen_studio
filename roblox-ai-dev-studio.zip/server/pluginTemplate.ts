// Helper to construct Luau Plugin for Roblox Studio with live bidirectional sync
export function getPluginLuaCode(baseUrl: string): string {
  const targetUrl = baseUrl || "https://ais-dev-et6lhzpgxli5bcdq6kookw-655207433296.europe-west1.run.app";

  return `--!strict
-- =========================================================================
-- BLOXGEN STUDIO: ROBLOX STUDIO LIVE SYNC PLUGIN (.luau)
-- Sincronizzazione real-time con BloxGen Web Studio (Gemini AI)
-- =========================================================================

local HttpService = game:GetService("HttpService")
local ChangeHistoryService = game:GetService("ChangeHistoryService")
local LogService = game:GetService("LogService")
local RunService = game:GetService("RunService")

-- Configurazione iniziale
local DEFAULT_SERVER_URL = "${targetUrl}"
local SERVER_URL = DEFAULT_SERVER_URL
local POLL_INTERVAL = 1.5
local MAX_STORED_LOGS = 50

-- Stato del Plugin
local isConnected = false
local pollingActive = false
local pollThread: thread? = nil
local recentLogs: { { level: string, message: string, timestamp: number } } = {}
local logHistory: { string } = {}

-- Riferimenti UI
local statusBadge: TextLabel? = nil
local connectBtn: TextButton? = nil
local urlInput: TextBox? = nil
local logsConsole: TextLabel? = nil
local scrollFrame: ScrollingFrame? = nil

-- Gestione log a video
local function addGuiLog(msg: string)
	local timeStr = os.date("%X")
	local line = "[" .. timeStr .. "] " .. msg
	table.insert(logHistory, line)
	if #logHistory > 20 then
		table.remove(logHistory, 1)
	end
	if logsConsole then
		logsConsole.Text = table.concat(logHistory, "\\n")
	end
	if scrollFrame then
		task.defer(function()
			scrollFrame.CanvasPosition = Vector2.new(0, 999999)
		end)
	end
end

-- Diagnostica intelligente degli errori HTTP in Roblox Studio
local function diagnoseHttp(err: any, testUrl: string): (string, string)
	local errStr = tostring(err or "")
	local lower = string.lower(errStr)

	local isHttpEnabledProp: boolean? = nil
	pcall(function()
		isHttpEnabledProp = HttpService.HttpEnabled
	end)

	if isHttpEnabledProp == false or string.find(lower, "not enabled") or string.find(lower, "game settings") then
		return "⚠️ HttpService DISABILITATO in Studio",
			"Abilita le chiamate HTTP:\\n1. Studio: Home > Game Settings > Security\\n2. Attiva 'Allow HTTP Requests' [ON]\\n3. Clicca SAVE in basso a destra.\\n(Se il gioco è nuovo, fai prima File > Publish to Roblox)."
	end

	if string.find(lower, "cookie check") or string.find(lower, "__cookie_check") or string.find(lower, "<!doctype") then
		return "⚠️ Blocco Sicurezza Cookie Google AI Studio",
			"Roblox Studio non può accedere direttamente all'URL dev interno (ais-dev-...) perché Google richiede la sessione del browser!\\n\\nCOME RISOLVERE SUBITO:\\n1. Nel sito web BloxGen Studio, clicca su 'Condividi' o 'Share' in alto a destra su Google AI Studio.\\n2. Copia l'URL condiviso pubblico (ais-pre-...run.app) e incollalo qui.\\n(In alternativa usa ngrok o clicca 'Push Codice' direttamente dal sito)."
	end

	if string.find(lower, "localhost") or string.find(string.lower(testUrl), "localhost") or string.find(testUrl, "127.0.0.1") then
		return "❌ Errore URL: Roblox blocca localhost",
			"Roblox Studio non può accedere a localhost!\\nUsa un URL pubblico HTTPS (es. ngrok o Cloud Run).\\nIncollalo nella barra 'URL Server'."
	end

	if string.find(lower, "connectfail") then
		return "❌ Errore ConnectFail (Server non raggiungibile)",
			"Impossibile raggiungere " .. testUrl .. ".\\nVerifica che il server backend sia online e attivo."
	end

	if string.find(lower, "dnsresolve") then
		return "❌ Errore DnsResolve (Dominio inesistente)",
			"Impossibile risolvere il dominio " .. testUrl .. ".\\nControlla la sintassi dell'indirizzo web."
	end

	if string.find(lower, "trust check") then
		return "❌ Roblox Trust Check Fallito",
			"Roblox rifiuta la connessione a questo indirizzo: " .. errStr .. "\\nAssicurati che sia un indirizzo HTTPS sicuro."
	end

	return "❌ Errore di connessione", "Dettaglio: " .. errStr
end

-- Risoluzione ricorsiva percorsi (es. "ReplicatedStorage.Modules.Player")
local function resolveParent(parentPath: string): Instance?
	if not parentPath or parentPath == "" then
		return game:GetService("ServerScriptService")
	end

	-- Normalizza delimitatori
	local cleanPath = string.gsub(parentPath, "/", ".")
	local segments = string.split(cleanPath, ".")

	local rootServiceName = segments[1]
	local currentParent: Instance? = nil

	if rootServiceName == "Workspace" or rootServiceName == "workspace" then
		currentParent = workspace
	else
		local ok, service = pcall(function()
			return game:GetService(rootServiceName)
		end)
		if ok and service then
			currentParent = service
		end
	end

	if not currentParent then
		-- Fallback a ServerScriptService
		currentParent = game:GetService("ServerScriptService")
	end

	-- Crea o naviga cartelle intermedie
	for i = 2, #segments do
		local segName = segments[i]
		if segName ~= "" then
			local child = currentParent:FindFirstChild(segName)
			if not child then
				local newFolder = Instance.new("Folder")
				newFolder.Name = segName
				newFolder.Parent = currentParent
				currentParent = newFolder
			else
				currentParent = child
			end
		end
	end

	return currentParent
end

-- Applica file di codice sincronizzato con registrazione Undo/Redo moderna
local function applySyncFile(fileData: { name: string?, type: string?, parentPath: string?, content: string? }): boolean
	local name = fileData.name or "ScriptGenerato"
	local fileType = fileData.type or "Server"
	local parentPath = fileData.parentPath or "ServerScriptService"
	local content = fileData.content or ""

	local parent = resolveParent(parentPath)
	if not parent then
		warn("⚠️ [BloxGen] Impossibile risolvere genitore per: " .. parentPath)
		addGuiLog("⚠️ Errore percorso: " .. parentPath)
		return false
	end

	local className = "Script"
	if fileType == "LocalScript" then
		className = "LocalScript"
	elseif fileType == "ModuleScript" then
		className = "ModuleScript"
	end

	-- Registra cronologia Undo/Redo
	local recordId = nil
	pcall(function()
		recordId = ChangeHistoryService:TryBeginRecording("BloxGen Sync: " .. name)
	end)

	local existing = parent:FindFirstChild(name)
	if existing and existing:IsA("LuaSourceContainer") then
		(existing :: LuaSourceContainer).Source = content
		print("🔄 [BloxGen] Aggiornato script: " .. parentPath .. "." .. name)
		addGuiLog("🔄 Aggiornato: " .. name)
	else
		local newScript = Instance.new(className)
		newScript.Name = name
		newScript.Source = content
		newScript.Parent = parent
		print("✨ [BloxGen] Creato " .. className .. ": " .. parentPath .. "." .. name)
		addGuiLog("✨ Creato: " .. name)
	end

	if recordId then
		pcall(function()
			ChangeHistoryService:FinishRecording(recordId, Enum.FinishRecordingOperation.Commit)
		end)
	end

	return true
end

-- Esecuzione comandi Luau remoti in sicurezza
local function executeRemoteCommand(cmd: string)
	print("⚙️ [BloxGen] Esecuzione comando: " .. cmd)
	addGuiLog("⚙️ Esecuzione comando remoti...")

	local func, syntaxErr = loadstring(cmd)
	if not func then
		warn("❌ [BloxGen] Errore sintassi: " .. tostring(syntaxErr))
		addGuiLog("❌ Errore sintassi comando")
		return
	end

	local recordId = nil
	pcall(function()
		recordId = ChangeHistoryService:TryBeginRecording("BloxGen Command Exec")
	end)

	local ok, execErr = pcall(func)
	if not ok then
		warn("❌ [BloxGen] Errore esecuzione: " .. tostring(execErr))
		addGuiLog("❌ Errore exec: " .. tostring(execErr))
	else
		print("✅ [BloxGen] Comando completato con successo!")
		addGuiLog("✅ Comando eseguito!")
	end

	if recordId then
		pcall(function()
			ChangeHistoryService:FinishRecording(recordId, Enum.FinishRecordingOperation.Commit)
		end)
	end
end

-- Cattura i log di output/errore (con limite di memoria circolare)
local logConnection = LogService.MessageOut:Connect(function(message: string, messageType: Enum.MessageType)
	local level = "info"
	if messageType == Enum.MessageType.MessageWarning then
		level = "warning"
	elseif messageType == Enum.MessageType.MessageError then
		level = "error"
	end

	if not string.find(message, "%[BloxGen%]") then
		if #recentLogs >= MAX_STORED_LOGS then
			table.remove(recentLogs, 1)
		end
		table.insert(recentLogs, {
			level = level,
			message = message,
			timestamp = os.time() * 1000,
		})
	end
end)

-- Handshake verso il server (con guardia contro PlaceId == 0)
local function sendHandshake(targetUrl: string)
	local placeName = "Roblox Place (Non pubblicato)"

	if game.PlaceId > 0 then
		pcall(function()
			local info = game:GetService("MarketplaceService"):GetProductInfo(game.PlaceId)
			if info and info.Name then
				placeName = info.Name
			end
		end)
	elseif game.Name and game.Name ~= "" then
		placeName = game.Name
	end

	-- 1. Tentativo con query params GET
	local encodedPlaceName = HttpService:UrlEncode(placeName)
	local handshakeUrl = targetUrl .. "/api/sync/handshake?placeName=" .. encodedPlaceName .. "&placeId=" .. tostring(game.PlaceId) .. "&studio=1"

	local ok, err = pcall(function()
		return HttpService:GetAsync(handshakeUrl)
	end)

	-- 2. Fallback POST se GET non risponde
	if not ok then
		local payload = HttpService:JSONEncode({
			placeName = placeName,
			placeId = game.PlaceId,
			studioVersion = RunService:IsStudio() and "Roblox Studio (Active)" or "Roblox Client",
		})
		ok, err = pcall(function()
			return HttpService:PostAsync(
				targetUrl .. "/api/sync/handshake",
				payload,
				Enum.HttpContentType.ApplicationJson,
				false
			)
		end)
	end

	if ok then
		addGuiLog("🤝 Handshake registrato sul server: " .. placeName)
	else
		warn("⚠️ Handshake warning: " .. tostring(err))
		addGuiLog("⚠️ Handshake non registrato: " .. tostring(err))
	end
end

-- Loop di sincronizzazione e polling controllato
local function stopPolling()
	pollingActive = false
	if pollThread then
		task.cancel(pollThread)
		pollThread = nil
	end
end

local function startPollingLoop(targetUrl: string)
	stopPolling()
	pollingActive = true

	pollThread = task.spawn(function()
		print("🚀 [BloxGen Studio] Loop di sincronizzazione avviato.")
		addGuiLog("🚀 Loop sincronizzazione attivo.")

		while pollingActive and isConnected do
			-- 1. Invio log accumulati
			if #recentLogs > 0 then
				local logsToSend = recentLogs
				recentLogs = {}
				pcall(function()
					HttpService:PostAsync(
						targetUrl .. "/api/sync/report-logs",
						HttpService:JSONEncode({ logs = logsToSend }),
						Enum.HttpContentType.ApplicationJson,
						false
					)
				end)
			end

			-- 2. Ricezione modifiche da BloxGen
			local pollOk, pollRes = pcall(function()
				return HttpService:GetAsync(targetUrl .. "/api/sync/poll")
			end)

			if pollOk and pollRes and pollRes ~= "" then
				local decodeOk, data = pcall(function()
					return HttpService:JSONDecode(pollRes)
				end)

				if decodeOk and typeof(data) == "table" and data.success then
					-- Sincronizzazione Script
					if data.files and typeof(data.files) == "table" then
						for _, fileData in ipairs(data.files) do
							applySyncFile(fileData)
						end
					end

					-- Esecuzione comandi remoti
					if data.commands and typeof(data.commands) == "table" then
						for _, cmdData in ipairs(data.commands) do
							if cmdData.command then
								executeRemoteCommand(cmdData.command)
							end
						end
					end
				end
			end

			task.wait(POLL_INTERVAL)
		end
		pollingActive = false
	end)
end

-- Creazione dell'Interfaccia Grafica
local function setupGui(parentGui: Instance)
	local frame = Instance.new("Frame")
	frame.Name = "BloxGenMainPanel"
	frame.Size = UDim2.new(1, 0, 1, 0)
	frame.BackgroundColor3 = Color3.fromRGB(15, 23, 42)
	frame.BorderSizePixel = 0
	frame.Parent = parentGui

	-- Header
	local header = Instance.new("Frame")
	header.Name = "Header"
	header.Size = UDim2.new(1, 0, 0, 56)
	header.BackgroundColor3 = Color3.fromRGB(24, 30, 48)
	header.BorderSizePixel = 0
	header.Parent = frame

	local title = Instance.new("TextLabel")
	title.Size = UDim2.new(1, -24, 0, 24)
	title.Position = UDim2.new(0, 12, 0, 8)
	title.BackgroundTransparency = 1
	title.Text = "⚡ BloxGen Studio"
	title.TextColor3 = Color3.fromRGB(255, 255, 255)
	title.Font = Enum.Font.GothamBold
	title.TextSize = 16
	title.TextXAlignment = Enum.TextXAlignment.Left
	title.Parent = header

	local subtitle = Instance.new("TextLabel")
	subtitle.Size = UDim2.new(1, -24, 0, 18)
	subtitle.Position = UDim2.new(0, 12, 0, 30)
	subtitle.BackgroundTransparency = 1
	subtitle.Text = "Live AI Bridge • Gemini Sync Engine"
	subtitle.TextColor3 = Color3.fromRGB(148, 163, 184)
	subtitle.Font = Enum.Font.Gotham
	subtitle.TextSize = 11
	subtitle.TextXAlignment = Enum.TextXAlignment.Left
	subtitle.Parent = header

	-- Card URL Server
	local siteCard = Instance.new("Frame")
	siteCard.Size = UDim2.new(1, -24, 0, 68)
	siteCard.Position = UDim2.new(0, 12, 0, 66)
	siteCard.BackgroundColor3 = Color3.fromRGB(30, 41, 59)
	siteCard.BorderSizePixel = 0
	siteCard.Parent = frame

	local siteCorner = Instance.new("UICorner")
	siteCorner.CornerRadius = UDim.new(0, 8)
	siteCorner.Parent = siteCard

	local siteLabel = Instance.new("TextLabel")
	siteLabel.Size = UDim2.new(1, -16, 0, 18)
	siteLabel.Position = UDim2.new(0, 8, 0, 6)
	siteLabel.BackgroundTransparency = 1
	siteLabel.Text = "Indirizzo Server Web BloxGen Studio:"
	siteLabel.TextColor3 = Color3.fromRGB(148, 163, 184)
	siteLabel.Font = Enum.Font.GothamMedium
	siteLabel.TextSize = 11
	siteLabel.TextXAlignment = Enum.TextXAlignment.Left
	siteLabel.Parent = siteCard

	urlInput = Instance.new("TextBox")
	urlInput.Size = UDim2.new(1, -16, 0, 30)
	urlInput.Position = UDim2.new(0, 8, 0, 28)
	urlInput.BackgroundColor3 = Color3.fromRGB(15, 23, 42)
	urlInput.BorderSizePixel = 0
	urlInput.Text = SERVER_URL
	urlInput.TextColor3 = Color3.fromRGB(52, 211, 153)
	urlInput.Font = Enum.Font.Code
	urlInput.TextSize = 10
	urlInput.ClearTextOnFocus = false
	urlInput.TextXAlignment = Enum.TextXAlignment.Left
	urlInput.PlaceholderText = "https://tuo-servizio.run.app"
	urlInput.Parent = siteCard

	local urlCorner = Instance.new("UICorner")
	urlCorner.CornerRadius = UDim.new(0, 6)
	urlCorner.Parent = urlInput

	-- Badge Stato
	statusBadge = Instance.new("TextLabel")
	statusBadge.Size = UDim2.new(1, -24, 0, 40)
	statusBadge.Position = UDim2.new(0, 12, 0, 142)
	statusBadge.BackgroundColor3 = Color3.fromRGB(24, 30, 48)
	statusBadge.BorderSizePixel = 0
	statusBadge.Text = "🔴 Disconnesso (Clicca sotto per collegarti)"
	statusBadge.TextColor3 = Color3.fromRGB(248, 113, 113)
	statusBadge.Font = Enum.Font.GothamMedium
	statusBadge.TextSize = 11
	statusBadge.TextWrapped = true
	statusBadge.Parent = frame

	local statusCorner = Instance.new("UICorner")
	statusCorner.CornerRadius = UDim.new(0, 6)
	statusCorner.Parent = statusBadge

	-- Bottone Connessione
	connectBtn = Instance.new("TextButton")
	connectBtn.Size = UDim2.new(1, -24, 0, 44)
	connectBtn.Position = UDim2.new(0, 12, 0, 190)
	connectBtn.BackgroundColor3 = Color3.fromRGB(225, 29, 72)
	connectBtn.BorderSizePixel = 0
	connectBtn.Text = "⚡ Connetti a BloxGen Studio"
	connectBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
	connectBtn.Font = Enum.Font.GothamBold
	connectBtn.TextSize = 13
	connectBtn.AutoButtonColor = true
	connectBtn.Parent = frame

	local btnCorner = Instance.new("UICorner")
	btnCorner.CornerRadius = UDim.new(0, 8)
	btnCorner.Parent = connectBtn

	-- Log Box con Auto-Scroll
	scrollFrame = Instance.new("ScrollingFrame")
	scrollFrame.Size = UDim2.new(1, -24, 1, -252)
	scrollFrame.Position = UDim2.new(0, 12, 0, 242)
	scrollFrame.BackgroundColor3 = Color3.fromRGB(10, 15, 26)
	scrollFrame.BorderSizePixel = 0
	scrollFrame.ScrollBarThickness = 4
	scrollFrame.ScrollBarImageColor3 = Color3.fromRGB(71, 85, 105)
	scrollFrame.AutomaticCanvasSize = Enum.AutomaticSize.Y
	scrollFrame.CanvasSize = UDim2.new(0, 0, 0, 0)
	scrollFrame.Parent = frame

	local scrollCorner = Instance.new("UICorner")
	scrollCorner.CornerRadius = UDim.new(0, 6)
	scrollCorner.Parent = scrollFrame

	logsConsole = Instance.new("TextLabel")
	logsConsole.Size = UDim2.new(1, -12, 0, 0)
	logsConsole.Position = UDim2.new(0, 6, 0, 6)
	logsConsole.AutomaticSize = Enum.AutomaticSize.Y
	logsConsole.BackgroundTransparency = 1
	logsConsole.TextColor3 = Color3.fromRGB(203, 213, 225)
	logsConsole.Font = Enum.Font.Code
	logsConsole.TextSize = 10
	logsConsole.TextXAlignment = Enum.TextXAlignment.Left
	logsConsole.TextYAlignment = Enum.TextYAlignment.Top
	logsConsole.TextWrapped = true
	logsConsole.Text = "[BloxGen] Plugin pronto. Inserisci l'URL e premi Connetti."
	logsConsole.Parent = scrollFrame

	-- Logica Click Bottone
	connectBtn.MouseButton1Click:Connect(function()
		if not isConnected then
			local rawUrl = (urlInput and urlInput.Text) or SERVER_URL
			rawUrl = string.gsub(rawUrl, "^%s+", "")
			rawUrl = string.gsub(rawUrl, "%s+$", "")
			rawUrl = string.gsub(rawUrl, "/+$", "")

			if rawUrl == "" then
				rawUrl = DEFAULT_SERVER_URL
				if urlInput then urlInput.Text = DEFAULT_SERVER_URL end
			end

			if statusBadge then
				statusBadge.Text = "🟡 Verifica connessione..."
				statusBadge.TextColor3 = Color3.fromRGB(251, 191, 36)
			end
			connectBtn.Text = "⏳ Connessione..."
			addGuiLog("Test connessione verso " .. rawUrl .. "...")

			local httpOk, resText = pcall(function()
				return HttpService:GetAsync(rawUrl .. "/api/health?studio=1")
			end)

			if not httpOk then
				local badgeMsg, logMsg = diagnoseHttp(resText, rawUrl)
				if statusBadge then
					statusBadge.Text = badgeMsg
					statusBadge.TextColor3 = Color3.fromRGB(248, 113, 113)
				end
				connectBtn.Text = "⚡ Riprova Connessione"
				connectBtn.BackgroundColor3 = Color3.fromRGB(225, 29, 72)
				addGuiLog(badgeMsg)

				for _, line in ipairs(string.split(logMsg, "\\n")) do
					addGuiLog(line)
				end
				warn("❌ [BloxGen] Connessione fallita: " .. tostring(resText))
				return
			end

			-- Riconoscimento del blocco cookie di Google AI Studio
			local lowerRes = string.lower(tostring(resText))
			if string.find(lowerRes, "cookie check") or string.find(lowerRes, "__cookie_check") or string.find(lowerRes, "<!doctype") then
				local badgeMsg, logMsg = diagnoseHttp("cookie check", rawUrl)
				if statusBadge then
					statusBadge.Text = badgeMsg
					statusBadge.TextColor3 = Color3.fromRGB(251, 191, 36)
				end
				connectBtn.Text = "⚡ Riprova con Link Share"
				connectBtn.BackgroundColor3 = Color3.fromRGB(225, 29, 72)
				addGuiLog(badgeMsg)
				for _, line in ipairs(string.split(logMsg, "\\n")) do
					addGuiLog(line)
				end
				warn("⚠️ [BloxGen] " .. badgeMsg)
				return
			end

			local decodeOk, healthData = pcall(function()
				return HttpService:JSONDecode(resText)
			end)

			if not decodeOk or typeof(healthData) ~= "table" or healthData.status ~= "ok" then
				local badgeMsg = "❌ Risposta non valida dal server"
				if statusBadge then
					statusBadge.Text = badgeMsg
					statusBadge.TextColor3 = Color3.fromRGB(248, 113, 113)
				end
				connectBtn.Text = "⚡ Riprova Connessione"
				connectBtn.BackgroundColor3 = Color3.fromRGB(225, 29, 72)
				addGuiLog(badgeMsg)
				addGuiLog("Il server non ha restituito JSON valido. Controlla l'URL.")
				return
			end

			-- Connessione riuscita e handshake immediato
			SERVER_URL = rawUrl
			isConnected = true

			if statusBadge then
				statusBadge.Text = "🟢 Connesso! Sincronizzazione in tempo reale attiva"
				statusBadge.TextColor3 = Color3.fromRGB(52, 211, 153)
			end
			connectBtn.Text = "⏹️ Disconnetti da BloxGen"
			connectBtn.BackgroundColor3 = Color3.fromRGB(51, 65, 85)

			addGuiLog("✅ Connesso a " .. SERVER_URL)
			sendHandshake(SERVER_URL)
			startPollingLoop(SERVER_URL)
		else
			-- Disconnessione manuale
			isConnected = false
			stopPolling()

			if statusBadge then
				statusBadge.Text = "🔴 Disconnesso (Sincronizzazione in pausa)"
				statusBadge.TextColor3 = Color3.fromRGB(248, 113, 113)
			end
			connectBtn.Text = "⚡ Connetti a BloxGen Studio"
			connectBtn.BackgroundColor3 = Color3.fromRGB(225, 29, 72)

			addGuiLog("⏹️ Disconnesso. Modifiche in pausa.")
		end
	end)
end

-- Inizializzazione Plugin
local isPluginObj = (typeof(plugin) == "Instance" and plugin:IsA("Plugin")) or (typeof(plugin) == "table" and plugin.CreateToolbar ~= nil)

if isPluginObj then
	local toolbar = plugin:CreateToolbar("BloxGen AI")
	local syncBtn = toolbar:CreateButton(
		"BloxGen Connect",
		"Apri la schermata di sincronizzazione live",
		"rbxassetid://10734950309"
	)
	syncBtn.ClickableWhenViewportHidden = true

	local widgetInfo = DockWidgetPluginGuiInfo.new(
		Enum.InitialDockState.Float,
		true,
		false,
		360,
		480,
		280,
		340
	)
	local widget = plugin:CreateDockWidgetPluginGui("BloxGenStudioLiveConnect", widgetInfo)
	widget.Title = "BloxGen Studio - Live Connect"
	setupGui(widget)

	syncBtn.Click:Connect(function()
		widget.Enabled = not widget.Enabled
	end)

	-- Pulizia memoria allo scaricamento del plugin
	plugin.Unloading:Connect(function()
		isConnected = false
		stopPolling()
		if logConnection then
			logConnection:Disconnect()
		end
	end)

	print("✅ [BloxGen] Plugin caricato nella barra PLUGINS.")
else
	-- Fallback modalità script standard
	local screenGui = Instance.new("ScreenGui")
	screenGui.Name = "BloxGenStudioLiveGui"
	screenGui.ResetOnSpawn = false

	local win = Instance.new("Frame")
	win.Name = "BloxGenFloatingWin"
	win.Size = UDim2.new(0, 360, 0, 480)
	win.Position = UDim2.new(0.5, -180, 0.5, -240)
	win.BackgroundColor3 = Color3.fromRGB(15, 23, 42)
	win.Parent = screenGui

	local winCorner = Instance.new("UICorner")
	winCorner.CornerRadius = UDim.new(0, 8)
	winCorner.Parent = win

	setupGui(win)

	local okParent = pcall(function()
		screenGui.Parent = game:GetService("CoreGui")
	end)
	if not okParent or not screenGui.Parent then
		screenGui.Parent = game:GetService("StarterGui")
	end

	print("✅ [BloxGen] Script avviato in modalità GUI di fallback.")
end
`;
}

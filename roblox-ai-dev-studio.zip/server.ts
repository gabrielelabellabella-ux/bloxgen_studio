import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";
import { getPluginLuaCode } from "./server/pluginTemplate";

dotenv.config();

const app = express();
const PORT = 3000;

// Support large image payloads for screenshots and asset uploads
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Helper to get or initialize Gemini client
function getGeminiClient(customKey?: string): GoogleGenAI {
  const key = customKey || process.env.GEMINI_API_KEY;
  if (!key) {
    throw new Error("GEMINI_API_KEY non configurata. Imposta la chiave nelle variabili d'ambiente (Settings > Secrets).");
  }
  return new GoogleGenAI({
    apiKey: key,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

const MODEL_NAME = "gemini-3.8-flash";

interface QueuedSyncFile {
  id: string;
  name: string;
  type: string;
  parentPath: string;
  content: string;
  timestamp: number;
}

interface QueuedCommand {
  id: string;
  command: string;
  timestamp: number;
}

interface StudioLog {
  id: string;
  timestamp: number;
  level: "info" | "warning" | "error";
  message: string;
  stackTrace?: string;
}

let studioSession = {
  connected: false,
  placeName: "Nessun Posto Rilevato",
  placeId: 0,
  studioVersion: "Roblox Studio",
  lastHeartbeat: 0,
  autoSync: true,
  clientIp: "",
};

let pendingSyncFiles: QueuedSyncFile[] = [];
let pendingCommands: QueuedCommand[] = [];
let studioLogs: StudioLog[] = [];

// Helper to check live connection (heartbeat within 45s to avoid false disconnects over WAN/Studio lags)
function isStudioActive(): boolean {
  return Date.now() - studioSession.lastHeartbeat < 45000;
}

// 1. Health check
app.get("/api/health", (req, res) => {
  const isStudio = req.query.studio === "1" || req.get("user-agent")?.toLowerCase().includes("roblox");
  if (isStudio) {
    studioSession.lastHeartbeat = Date.now();
    studioSession.connected = true;
    if (req.query.placeName) studioSession.placeName = String(req.query.placeName);
  }

  res.json({
    status: "ok",
    model: MODEL_NAME,
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    studioConnected: isStudioActive(),
  });
});

// 2. Generate Luau script from prompt
app.post("/api/gemini/generate-lua", async (req, res) => {
  try {
    const { prompt, scriptType, existingCode, projectStructure, assetImages } = req.body;
    const clientKey = req.headers["x-gemini-key"] as string | undefined;
    const ai = getGeminiClient(clientKey);

    const systemInstruction = `Sei il massimo esperto mondiale di sviluppo Roblox, programmazione Luau moderno, motori di gioco Roblox Studio e architetture performanti.
Regole per la scrittura di codice Luau:
1. Usa sintassi Luau moderna con type annotations (--!strict o --!native se applicabile).
2. Usa sempre la libreria 'task' (task.wait, task.spawn, task.defer, task.cancel) e MAI wait() o spawn() deprecati.
3. Ottieni sempre i servizi con game:GetService("NomeServizio") una sola volta in cima al file.
4. Segui le convenzioni Roblox: PascalCase per proprietà e metodi (FindFirstChild, WaitForChild, Connect).
5. Scrivi codice sicuro, modulare, pulito, documentato in italiano.
6. Se vengono menzionati asset grafici o decal/immagini, integra correttamente le proprietà rbxassetid:// o le Texture/Decal/ImageLabel con UDim2.fromScale().
7. Rispondi con un JSON strutturato valido contenente:
{
  "title": "Breve titolo dello script",
  "scriptType": "Server" | "LocalScript" | "ModuleScript",
  "location": "e.g. ServerScriptService, StarterPlayerScripts, ReplicatedStorage, StarterGui",
  "summary": "Breve spiegazione in italiano di cosa fa e come implementarlo",
  "code": "Codice Luau completo e pronto da copiare",
  "services": ["Players", "TweenService", ...],
  "optimizations": ["Suggerimenti e buone pratiche adottate"]
}`;

    const parts: any[] = [];

    // If asset images are provided in the prompt
    if (Array.isArray(assetImages) && assetImages.length > 0) {
      for (const img of assetImages) {
        if (img.data && img.mimeType) {
          parts.push({
            inlineData: {
              data: img.data.replace(/^data:[^;]+;base64,/, ""),
              mimeType: img.mimeType,
            },
          });
        }
      }
    }

    const promptText = `PROMPT UTENTE: ${prompt}
Tipo di Script richiesto: ${scriptType || "Automatico"}
Struttura Progetto attuale: ${projectStructure ? JSON.stringify(projectStructure) : "Progetto Standard Roblox Studio"}
${existingCode ? `Codice Esistente da modificare/estendere:\n\`\`\`lua\n${existingCode}\n\`\`\`` : ""}
Genera lo script Luau completo e dettagliato seguendo il formato JSON specificato.`;

    parts.push({ text: promptText });

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: { parts },
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        temperature: 0.2,
      },
    });

    const rawText = response.text || "{}";
    const data = JSON.parse(rawText);
    res.json({ success: true, ...data });
  } catch (err: any) {
    console.error("Error in /api/gemini/generate-lua:", err);
    res.status(500).json({
      success: false,
      error: err.message || "Errore durante la generazione dello script Lua con Gemini 3.8",
    });
  }
});

// 3. Screenshot to Roblox UI Converter (Multimodal Vision)
app.post("/api/gemini/convert-ui", async (req, res) => {
  try {
    const { imageBase64, mimeType, instructions, targetDevice } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ success: false, error: "Screenshot mancante" });
    }

    const clientKey = req.headers["x-gemini-key"] as string | undefined;
    const ai = getGeminiClient(clientKey);

    const cleanBase64 = imageBase64.replace(/^data:[^;]+;base64,/, "");
    const actualMime = mimeType || "image/png";

    const systemInstruction = `Sei un ingegnere UI/UX specializzato in Roblox Studio e Luau UI (ScreenGui, Roact, Fusion).
Il tuo compito è analizzare accuratamente lo screenshot dell'interfaccia utente fornito e convertirlo in una UI Roblox nativa, perfetta e completamente RESPONSIVA.
REGOLE PER LA CONVERSIONE UI ROBLOX:
1. Usa SOLO scale UDim2.fromScale(x, y) per garantire che la UI scali perfettamente su Mobile, PC, Tablet e Console (MAI offset fissi in pixel a meno di piccoli margini interni).
2. Aggiungi sempre componenti moderni come UIAspectRatioConstraint per evitare deformazioni di icone o elementi quadrati.
3. Riconosci bordi arrotondati (UICorner), gradienti (UIGradient), contorni (UIStroke) e layout automatici (UIListLayout, UIGridLayout).
4. Restituisci una rappresentazione gerarchica JSON degli elementi UI rilevati (per la preview grafica interattiva) E il codice Luau completo, pronto da copiare ed eseguire come LocalScript in StarterGui.
Formato JSON richiesto:
{
  "uiTitle": "Titolo UI rilevata (es: RPG HUD & HealthBar)",
  "colorPalette": ["#HEX1", "#HEX2", ...],
  "componentsCount": 12,
  "responsiveAdvice": "Consigli specifici per scaling multi-device (Mobile/PC/Tablet)",
  "elements": [
    {
      "id": "main_frame",
      "name": "MainContainer",
      "type": "Frame" | "ImageLabel" | "TextLabel" | "ImageButton" | "TextButton",
      "position": { "xScale": 0.5, "yScale": 0.5 },
      "size": { "xScale": 0.6, "yScale": 0.4 },
      "anchorPoint": { "x": 0.5, "y": 0.5 },
      "backgroundColor": "#1a1a24",
      "backgroundTransparency": 0.2,
      "text": "",
      "textColor": "#ffffff",
      "textSize": 16,
      "cornerRadius": 12,
      "strokeColor": "#3b82f6",
      "strokeThickness": 2,
      "children": []
    }
  ],
  "luauCode": "-- Codice Luau completo con Instance.new(...)"
}`;

    const parts = [
      {
        inlineData: {
          data: cleanBase64,
          mimeType: actualMime,
        },
      },
      {
        text: `Analizza questa schermata di interfaccia utente e convertila in elementi grafici Roblox Studio.
Istruzioni aggiuntive dell'utente: ${instructions || "Replica fedelmente ogni elemento, colori, testi, barre e pulsanti con responsive scaling."}
Dispositivo di riferimento primario: ${targetDevice || "Responsive Multi-Device (PC, Tablet, Mobile)"}.
Fornisci il JSON con la gerarchia visiva per l'anteprima e lo script Luau completo.`,
      },
    ];

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: { parts },
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        temperature: 0.1,
      },
    });

    const rawText = response.text || "{}";
    const data = JSON.parse(rawText);
    res.json({ success: true, ...data });
  } catch (err: any) {
    console.error("Error in /api/gemini/convert-ui:", err);
    res.status(500).json({
      success: false,
      error: err.message || "Errore durante l'analisi visiva dello screenshot con Gemini 3.8",
    });
  }
});

// 4. Real-time Luau Debugger & Syntax Analyzer
app.post("/api/gemini/debug-lua", async (req, res) => {
  try {
    const { code, detectedErrors, context } = req.body;
    const clientKey = req.headers["x-gemini-key"] as string | undefined;
    const ai = getGeminiClient(clientKey);

    const systemInstruction = `Sei un debugger Luau di livello enterprise per Roblox Studio.
Analizza il codice fornito per:
1. Errori di sintassi (parole chiave mancanti, 'end' non chiusi, parentesi o parentesi graffe sbilanciate).
2. Errori di runtime tipici di Roblox (indexing nil, tentativi di accedere a proprietà client da server, chiamate a metodi inesistenti o deprecati come :connect() invece di :Connect()).
3. Errori logici o memory leak (connessioni ad eventi non disconnesse con :Disconnect(), cicli infiniti senza task.wait).
Restituisci un JSON strutturato:
{
  "isValid": boolean,
  "summary": "Sintesi dei problemi rilevati",
  "issues": [
    {
      "line": 14,
      "severity": "error" | "warning" | "info",
      "message": "Spiegazione dell'errore",
      "suggestion": "Come risolverlo"
    }
  ],
  "fixedCode": "Il codice Luau completamente corretto e formattato",
  "explanation": "Spiegazione dettagliata delle correzioni applicate in italiano"
}`;

    const promptText = `ANALISI CODICE LUAU DA DEBUGGARE:
\`\`\`lua
${code}
\`\`\`
Errori locali pre-rilevati dal linter: ${JSON.stringify(detectedErrors || [])}
Contesto script: ${context || "Roblox Script"}
Fornisci diagnosi e codice corretto nel formato JSON specificato.`;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: promptText,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        temperature: 0.1,
      },
    });

    const rawText = response.text || "{}";
    const data = JSON.parse(rawText);
    res.json({ success: true, ...data });
  } catch (err: any) {
    console.error("Error in /api/gemini/debug-lua:", err);
    res.status(500).json({
      success: false,
      error: err.message || "Errore durante il debugging con Gemini 3.8",
    });
  }
});

// 5. Performance Optimizer & Code Profiler
app.post("/api/gemini/optimize-lua", async (req, res) => {
  try {
    const { code, targetFPS } = req.body;
    const clientKey = req.headers["x-gemini-key"] as string | undefined;
    const ai = getGeminiClient(clientKey);

    const systemInstruction = `Sei un esperto di ottimizzazione delle prestazioni e micro-ottimizzazioni del motore Luau di Roblox.
Analizza il codice fornito per massimizzare il framerate, ridurre l'uso di memoria, abbattere il lag di rete e prevenire picchi del Garbage Collector.
Aree chiave:
- Sostituzione di funzioni globali con riferimenti locali in testa (es. local math_sin = math.sin)
- Uso di task.wait(), task.defer(), task.spawn()
- Throttling e batching per RemoteEvent/RemoteFunction
- Uso di array pre-allocati table.create() invece di inserimenti continui
- Cache delle istanze e dei servizi
- Disconnessione automatica di segnali RBXScriptSignal
- Uso dell'attributo --!native se contiene calcoli matematici pesanti
Restituisci un JSON:
{
  "performanceScoreBefore": 65,
  "performanceScoreAfter": 96,
  "optimizations": [
    {
      "category": "Memory" | "CPU" | "Network" | "Luau Native",
      "title": "Titolo ottimizzazione",
      "description": "Perché è stata applicata e quale impatto ha sulle prestazioni"
    }
  ],
  "optimizedCode": "Codice Luau interamente ottimizzato",
  "summary": "Sintesi dei miglioramenti in italiano"
}`;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: `Ottimizza il seguente script Luau per massime performance a ${targetFPS || 60} FPS:\n\`\`\`lua\n${code}\n\`\`\``,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        temperature: 0.1,
      },
    });

    const rawText = response.text || "{}";
    const data = JSON.parse(rawText);
    res.json({ success: true, ...data });
  } catch (err: any) {
    console.error("Error in /api/gemini/optimize-lua:", err);
    res.status(500).json({
      success: false,
      error: err.message || "Errore durante l'ottimizzazione con Gemini 3.8",
    });
  }
});

// 6. Roblox Graphic & Post-FX Generator (Motion Blur, Depth of Field, Lighting Presets)
app.post("/api/gemini/generate-fx", async (req, res) => {
  try {
    const { stylePrompt, presetName, customSettings } = req.body;
    const clientKey = req.headers["x-gemini-key"] as string | undefined;
    const ai = getGeminiClient(clientKey);

    const systemInstruction = `Sei un Lead Lighting & VFX Technical Artist per Roblox Studio.
Crei configurazioni di post-processing ed effetti grafici spettacolari:
- DepthOfFieldEffect (FocusDistance, InFocusRadius, NearIntensity, FarIntensity)
- BlurEffect e script di Motion Blur dinamico basato sul movimento della camera (RunService.RenderStepped)
- BloomEffect (Intensity, Size, Threshold)
- ColorCorrectionEffect (Brightness, Contrast, Saturation, TintColor)
- SunRaysEffect (Intensity, Spread)
- Atmosphere (Density, Offset, Color, Decay, Glare, Haze)
- Sky e Lighting properties (Technology = Future o ShadowMap, Ambient, OutdoorAmbient, Brightness, ExposureCompensation)
Restituisci un JSON:
{
  "presetName": "Nome preset",
  "description": "Descrizione dell'atmosfera grafica",
  "effects": {
    "depthOfField": { "enabled": true, "focusDistance": 25, "inFocusRadius": 15, "nearIntensity": 0.4, "farIntensity": 0.75 },
    "motionBlur": { "enabled": true, "blurSize": 8, "cameraSensibility": 1.2 },
    "bloom": { "enabled": true, "intensity": 0.8, "size": 24, "threshold": 1.2 },
    "colorCorrection": { "enabled": true, "brightness": 0.05, "contrast": 0.2, "saturation": 0.15, "tintColor": "#ffd4a3" },
    "sunRays": { "enabled": true, "intensity": 0.25, "spread": 0.8 }
  },
  "lightingProperties": {
    "technology": "Future",
    "brightness": 2.5,
    "clockTime": 17.5,
    "exposureCompensation": 0.1,
    "ambient": "#464655",
    "outdoorAmbient": "#78788a"
  },
  "installationScript": "-- Script completo da inserire in ServerScriptService o StarterPlayerScripts per applicare automaticamente il post-processing"
}`;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: `Crea configurazione grafica ed effetti per: ${stylePrompt || presetName || "Cinematic Next-Gen con Motion Blur e Depth of Field realistico"}. Impostazioni: ${JSON.stringify(customSettings || {})}`,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        temperature: 0.2,
      },
    });

    const rawText = response.text || "{}";
    const data = JSON.parse(rawText);
    res.json({ success: true, ...data });
  } catch (err: any) {
    console.error("Error in /api/gemini/generate-fx:", err);
    res.status(500).json({
      success: false,
      error: err.message || "Errore durante la generazione degli effetti visivi",
    });
  }
});

// --- Roblox Studio Live Sync Hub ---

// 7. Status of Roblox Studio Connection
app.get("/api/sync/status", (_req, res) => {
  const active = isStudioActive();
  studioSession.connected = active;
  res.json({
    success: true,
    connected: active,
    session: {
      ...studioSession,
      connected: active,
    },
    pendingFilesCount: pendingSyncFiles.length,
    pendingCommandsCount: pendingCommands.length,
    recentLogs: studioLogs.slice(-25),
  });
});

// Heartbeat ping from Studio
app.all("/api/sync/heartbeat", (req, res) => {
  studioSession.lastHeartbeat = Date.now();
  studioSession.connected = true;
  if (req.query.placeName) studioSession.placeName = String(req.query.placeName);
  res.json({ success: true, connected: true, timestamp: Date.now() });
});

// 8. Handshake from Roblox Studio Plugin (Supports both GET and POST)
app.all("/api/sync/handshake", (req, res) => {
  const placeName = req.body?.placeName || req.query?.placeName;
  const placeId = req.body?.placeId || req.query?.placeId;
  const studioVersion = req.body?.studioVersion || req.query?.studioVersion;
  studioSession.lastHeartbeat = Date.now();
  studioSession.connected = true;
  if (placeName) studioSession.placeName = String(placeName);
  if (placeId) studioSession.placeId = Number(placeId) || 0;
  if (studioVersion) studioSession.studioVersion = String(studioVersion);
  studioSession.clientIp = req.ip || req.socket.remoteAddress || "";

  // Add notification log
  studioLogs.push({
    id: `log-${Date.now()}`,
    timestamp: Date.now(),
    level: "info",
    message: `[Roblox Studio] Connesso al posto: "${studioSession.placeName}" (PlaceId: ${studioSession.placeId})`,
  });

  res.json({
    success: true,
    connected: true,
    message: "Handshake completato con successo",
    autoSync: studioSession.autoSync,
  });
});

// 9. Poll endpoint called by Roblox Studio Plugin
app.get("/api/sync/poll", (_req, res) => {
  studioSession.lastHeartbeat = Date.now();
  studioSession.connected = true;

  const filesToSync = [...pendingSyncFiles];
  const commandsToRun = [...pendingCommands];

  // Clear queues after fetching
  pendingSyncFiles = [];
  pendingCommands = [];

  res.json({
    success: true,
    connected: true,
    autoSync: studioSession.autoSync,
    files: filesToSync,
    commands: commandsToRun,
  });
});

// 10. Report Studio Logs / Errors back to BloxGen
app.post("/api/sync/report-logs", (req, res) => {
  const { logs } = req.body;
  studioSession.lastHeartbeat = Date.now();
  studioSession.connected = true;

  if (Array.isArray(logs)) {
    for (const log of logs) {
      studioLogs.push({
        id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        timestamp: log.timestamp || Date.now(),
        level: log.level || "info",
        message: log.message || "",
        stackTrace: log.stackTrace || "",
      });
    }
    // Cap logs at 100
    if (studioLogs.length > 100) {
      studioLogs = studioLogs.slice(-100);
    }
  }

  res.json({ success: true, count: logs?.length || 0 });
});

// 11. Push single file or batch from Web UI to Roblox Studio
app.post("/api/sync/push", (req, res) => {
  const { file, files } = req.body;
  const items = files || (file ? [file] : []);

  if (items.length === 0) {
    return res.status(400).json({ success: false, error: "Nessun file fornito per la sincronizzazione" });
  }

  for (const item of items) {
    // Avoid duplicate queueing for the same file name & parentPath
    pendingSyncFiles = pendingSyncFiles.filter(
      (p) => !(p.name === item.name && p.parentPath === item.parentPath)
    );
    pendingSyncFiles.push({
      id: item.id || `sync-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: item.name,
      type: item.type,
      parentPath: item.parentPath,
      content: item.content,
      timestamp: Date.now(),
    });
  }

  res.json({
    success: true,
    queued: items.length,
    totalPending: pendingSyncFiles.length,
    isStudioConnected: isStudioActive(),
  });
});

// 12. Push remote Luau command to run in Roblox Studio
app.post("/api/sync/command", (req, res) => {
  const { command } = req.body;
  if (!command) {
    return res.status(400).json({ success: false, error: "Comando vuoto" });
  }

  pendingCommands.push({
    id: `cmd-${Date.now()}`,
    command,
    timestamp: Date.now(),
  });

  res.json({
    success: true,
    queued: true,
    isStudioConnected: isStudioActive(),
  });
});

// 13. Toggle Auto-Sync
app.post("/api/sync/toggle-auto", (req, res) => {
  const { autoSync } = req.body;
  if (typeof autoSync === "boolean") {
    studioSession.autoSync = autoSync;
  } else {
    studioSession.autoSync = !studioSession.autoSync;
  }
  res.json({ success: true, autoSync: studioSession.autoSync });
});

// 14. Clear logs
app.post("/api/sync/clear-logs", (_req, res) => {
  studioLogs = [];
  res.json({ success: true });
});

// Helper to reliably detect public web app URL (accounting for Cloud Run proxies, referer, query params)
function resolveBaseUrl(req: express.Request): string {
  const fallbackUrl = "https://ais-dev-et6lhzpgxli5bcdq6kookw-655207433296.europe-west1.run.app";

  if (typeof req.query.origin === "string" && req.query.origin.trim().startsWith("http")) {
    const origin = req.query.origin.trim().replace(/\/+$/, "");
    if (!origin.includes("localhost") && !origin.includes("127.0.0.1")) {
      return origin;
    }
  }
  if (typeof req.query.url === "string" && req.query.url.trim().startsWith("http")) {
    const url = req.query.url.trim().replace(/\/+$/, "");
    if (!url.includes("localhost") && !url.includes("127.0.0.1")) {
      return url;
    }
  }

  const referer = req.get("referer");
  if (referer) {
    try {
      const parsed = new URL(referer);
      if (parsed.protocol.startsWith("http") && !parsed.hostname.includes("localhost") && !parsed.hostname.includes("127.0.0.1")) {
        return parsed.origin;
      }
    } catch (_) {}
  }

  const originHeader = req.get("origin");
  if (originHeader && originHeader.startsWith("http") && !originHeader.includes("localhost") && !originHeader.includes("127.0.0.1")) {
    return originHeader.replace(/\/+$/, "");
  }

  const forwardedHost = req.get("x-forwarded-host");
  if (forwardedHost && !forwardedHost.includes("localhost") && !forwardedHost.includes("127.0.0.1")) {
    const forwardedProto = req.get("x-forwarded-proto") || "https";
    return `${forwardedProto}://${forwardedHost}`;
  }

  const host = req.get("host") || "";
  if (host && !host.includes("localhost") && !host.includes("127.0.0.1")) {
    const protocol = req.protocol === "https" || req.get("x-forwarded-proto") === "https" ? "https" : "http";
    return `${protocol}://${host}`;
  }

  return fallbackUrl;
}

app.get("/api/sync/plugin.lua", (req, res) => {
  const baseUrl = resolveBaseUrl(req);
  const luaPlugin = getPluginLuaCode(baseUrl);

  res.setHeader("Content-Type", "text/plain; charset=utf-8");
  res.setHeader("Content-Disposition", 'inline; filename="BloxGenStudioLiveSync.lua"');
  res.send(luaPlugin);
});

// 17. Serve Official Roblox Studio Plugin Model (.rbxmx)
app.get("/api/sync/plugin.rbxmx", (req, res) => {
  const baseUrl = resolveBaseUrl(req);
  const luaPlugin = getPluginLuaCode(baseUrl);
  const safeLua = luaPlugin.replace(/\]\]>/g, ']]..">"');

  const rbxmxContent = `<roblox xmlns:xmime="http://www.w3.org/2005/05/xmlmime" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://www.roblox.com/roblox.xsd" version="4">
	<Meta name="ExplicitAutoJoints">true</Meta>
	<External>null</External>
	<External>nil</External>
	<Item class="Script" referent="RBXBloxGen001">
		<Properties>
			<string name="Name">BloxGenStudioLiveSync</string>
			<ProtectedString name="Source"><![CDATA[${safeLua}]]></ProtectedString>
			<bool name="Disabled">false</bool>
		</Properties>
	</Item>
</roblox>`;

  res.setHeader("Content-Type", "application/xml; charset=utf-8");
  res.setHeader("Content-Disposition", 'attachment; filename="BloxGenStudioLiveSync.rbxmx"');
  res.send(rbxmxContent);
});

// Vite middleware for development & static serving for production
async function startServer() {

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`BloxGen Studio server attivo su http://0.0.0.0:${PORT}`);
  });
}

startServer();
